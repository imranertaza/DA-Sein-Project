#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text,
  `pic` varchar(100) DEFAULT NULL,
  `country` varchar(155) DEFAULT NULL,
  `ComName` varchar(155) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `mobile` (`mobile`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `admin` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `country`, `ComName`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (1, `imranertaza12@gmail`.`com`, `7c222fb2927d828af22f592134e8932480637c0d`, `Syed Imran` `Ertaza`, 1924329315, `Noapara, Abhaynagar,` `Jessore`, `admin_1655732623`.`jpg`, NULL, NULL, 1, 1, 1, `2018-11-21` `18:05:40`, 1, `2022-06-20` `19:43:43`, NULL, NULL);


#
# TABLE STRUCTURE FOR: bank
#

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `account_no` bigint(100) NOT NULL,
  `balance` double unsigned NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`bank_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `bank_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

INSERT INTO `bank` (`bank_id`, `sch_id`, `name`, `account_no`, `balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (33, 20, `UCB`, 20502365987456, 25000, `2022-09-26` `08:52:58`, 23, NULL, `2022-09-28` `19:28:22`, NULL, NULL);
INSERT INTO `bank` (`bank_id`, `sch_id`, `name`, `account_no`, `balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (34, 23, `IFIC`, 23235235235, 10000, `2022-09-27` `12:04:56`, 26, 26, `2022-09-27` `11:08:30`, NULL, NULL);
INSERT INTO `bank` (`bank_id`, `sch_id`, `name`, `account_no`, `balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (35, 23, `ISLAMI`, 56347356765, 10000, `2022-09-27` `12:08:16`, 26, 26, `2022-09-27` `11:08:30`, NULL, NULL);
INSERT INTO `bank` (`bank_id`, `sch_id`, `name`, `account_no`, `balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (36, 22, `IBBL`, 9223372036854775807, 90000, `2022-09-27` `08:46:06`, 25, NULL, `2022-09-28` `19:29:42`, NULL, NULL);
INSERT INTO `bank` (`bank_id`, `sch_id`, `name`, `account_no`, `balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (37, 22, `IFIC`, 7767676787897867367, 45000, `2022-09-27` `08:46:14`, 25, NULL, `2022-09-28` `19:30:02`, NULL, NULL);


#
# TABLE STRUCTURE FOR: bank_deposit
#

DROP TABLE IF EXISTS `bank_deposit`;

CREATE TABLE `bank_deposit` (
  `dep_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `amount` double unsigned NOT NULL,
  `commont` text,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`dep_id`),
  KEY `sch_id` (`sch_id`),
  KEY `bank_id` (`bank_id`),
  CONSTRAINT `bank_deposit_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `bank_deposit_ibfk_2` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`bank_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `bank_deposit` (`dep_id`, `sch_id`, `bank_id`, `amount`, `commont`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (1, 23, 34, 20000, `joma`, `2022-09-27` `12:05:17`, 26, NULL, `2022-09-27` `11:05:17`, NULL, NULL);
INSERT INTO `bank_deposit` (`dep_id`, `sch_id`, `bank_id`, `amount`, `commont`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (2, 22, 36, 100000, `For business` `purpose`, `2022-09-28` `08:25:54`, 25, NULL, `2022-09-28` `19:25:54`, NULL, NULL);
INSERT INTO `bank_deposit` (`dep_id`, `sch_id`, `bank_id`, `amount`, `commont`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (3, 22, 37, 50000, `For business` `purpose`, `2022-09-28` `08:26:15`, 25, NULL, `2022-09-28` `19:26:15`, NULL, NULL);
INSERT INTO `bank_deposit` (`dep_id`, `sch_id`, `bank_id`, `amount`, `commont`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (4, 20, 33, 30000, `deposit some taka` `poisha`, `2022-09-28` `08:27:13`, 23, NULL, `2022-09-28` `19:27:13`, NULL, NULL);


#
# TABLE STRUCTURE FOR: bank_withdraw
#

DROP TABLE IF EXISTS `bank_withdraw`;

CREATE TABLE `bank_withdraw` (
  `wthd_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) NOT NULL,
  `sch_id` int(11) NOT NULL,
  `amount` double unsigned NOT NULL,
  `commont` text,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`wthd_id`),
  KEY `bank_id` (`bank_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `bank_withdraw_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`bank_id`) ON UPDATE CASCADE,
  CONSTRAINT `bank_withdraw_ibfk_2` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `bank_withdraw` (`wthd_id`, `bank_id`, `sch_id`, `amount`, `commont`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (1, 33, 20, 5000, `koida tk` `tullam`, `2022-09-28` `08:28:22`, 23, NULL, `2022-09-28` `19:28:22`, NULL, NULL);
INSERT INTO `bank_withdraw` (`wthd_id`, `bank_id`, `sch_id`, `amount`, `commont`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (2, 36, 22, 10000, `For business` `purpose`, `2022-09-28` `08:29:42`, 25, NULL, `2022-09-28` `19:29:42`, NULL, NULL);
INSERT INTO `bank_withdraw` (`wthd_id`, `bank_id`, `sch_id`, `amount`, `commont`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (3, 37, 22, 5000, `For business` `purpose`, `2022-09-28` `08:30:02`, 25, NULL, `2022-09-28` `19:30:02`, NULL, NULL);


#
# TABLE STRUCTURE FOR: brand
#

DROP TABLE IF EXISTS `brand`;

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(155) DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`brand_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `brand_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: chaque
#

DROP TABLE IF EXISTS `chaque`;

CREATE TABLE `chaque` (
  `chaque_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `chaque_number` int(22) NOT NULL,
  `to_name` varchar(155) DEFAULT NULL,
  `to` int(11) DEFAULT NULL,
  `from_name` varchar(155) DEFAULT NULL,
  `from` int(11) DEFAULT NULL,
  `from_loan_provider` int(11) DEFAULT NULL,
  `amount` double unsigned NOT NULL,
  `issue_date` date NOT NULL,
  `account_number` int(30) DEFAULT NULL,
  `status` enum('Pending','Bounce','Approved') NOT NULL DEFAULT 'Pending',
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`chaque_id`),
  KEY `sch_id` (`sch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `chaque` (`chaque_id`, `sch_id`, `chaque_number`, `to_name`, `to`, `from_name`, `from`, `from_loan_provider`, `amount`, `issue_date`, `account_number`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (1, 23, 2147483647, NULL, 26, NULL, 92, NULL, 200, `0000-00-00`, NULL, `Approved`, `2022-09-27` `12:05:54`, 0, 26, `2022-09-27` `11:06:31`, NULL, NULL);


#
# TABLE STRUCTURE FOR: customer_type
#

DROP TABLE IF EXISTS `customer_type`;

CREATE TABLE `customer_type` (
  `cus_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `type_name` varchar(155) NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`cus_type_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `customer_type_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (30, 20, `regular`, `2022-09-26` `08:23:15`, 20, `2022-09-26` `19:23:15`, NULL, NULL, NULL);
INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (32, 22, `regular`, `2022-09-26` `08:49:10`, 22, `2022-09-26` `19:49:10`, NULL, NULL, NULL);
INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (33, 20, `VIP`, `2022-09-26` `08:54:12`, 23, `2022-09-26` `19:54:12`, NULL, NULL, NULL);
INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (34, 20, `Regular`, `2022-09-26` `08:54:15`, 23, `2022-09-26` `19:54:15`, NULL, NULL, NULL);
INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (35, 23, `regular`, `2022-09-26` `10:58:18`, 23, `2022-09-27` `09:58:18`, NULL, NULL, NULL);
INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (36, 22, `VIP`, `2022-09-27` `08:40:07`, 25, `2022-09-27` `19:40:07`, NULL, NULL, NULL);
INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (37, 22, `Cip`, `2022-09-27` `08:40:12`, 25, `2022-09-27` `19:41:13`, 25, NULL, NULL);
INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (38, 24, `regular`, `2022-10-01` `12:22:37`, 24, `2022-10-01` `11:22:37`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `customer_name` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `father_name` varchar(55) DEFAULT NULL,
  `mother_name` varchar(55) DEFAULT NULL,
  `address` text,
  `present_address` text,
  `age` int(11) unsigned DEFAULT NULL,
  `mobile` int(11) DEFAULT NULL,
  `pic` varchar(55) DEFAULT NULL,
  `nid` varchar(155) DEFAULT NULL,
  `cus_type_id` int(11) NOT NULL,
  `balance` double NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `sch_id` (`sch_id`),
  KEY `cus_type_id` (`cus_type_id`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `customers_ibfk_2` FOREIGN KEY (`cus_type_id`) REFERENCES `customer_type` (`cus_type_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=latin1;

INSERT INTO `customers` (`customer_id`, `sch_id`, `customer_name`, `father_name`, `mother_name`, `address`, `present_address`, `age`, `mobile`, `pic`, `nid`, `cus_type_id`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (90, 20, `Hasan`, NULL, NULL, NULL, NULL, NULL, 1364578569, NULL, NULL, 33, `0`.`25999999999999`, `2022-09-26` `08:56:00`, 23, `2022-09-27` `20:10:14`, 23, NULL, NULL);
INSERT INTO `customers` (`customer_id`, `sch_id`, `customer_name`, `father_name`, `mother_name`, `address`, `present_address`, `age`, `mobile`, `pic`, `nid`, `cus_type_id`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (91, 20, `Mamun`, NULL, NULL, NULL, NULL, NULL, 1409532730, NULL, NULL, 30, 0, `2022-09-26` `08:56:28`, 23, `2022-09-26` `19:56:28`, NULL, NULL, NULL);
INSERT INTO `customers` (`customer_id`, `sch_id`, `customer_name`, `father_name`, `mother_name`, `address`, `present_address`, `age`, `mobile`, `pic`, `nid`, `cus_type_id`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (92, 23, `example`, NULL, NULL, NULL, NULL, NULL, 1924331313, NULL, NULL, 30, `119`.`83`, `2022-09-27` `09:59:29`, 23, `2022-09-27` `11:06:31`, 26, NULL, NULL);
INSERT INTO `customers` (`customer_id`, `sch_id`, `customer_name`, `father_name`, `mother_name`, `address`, `present_address`, `age`, `mobile`, `pic`, `nid`, `cus_type_id`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (93, 22, `Sojeb`, NULL, NULL, NULL, NULL, NULL, 1744444444, NULL, NULL, 36, 0, `2022-09-27` `08:43:21`, 25, `2022-09-27` `20:03:34`, 25, NULL, NULL);
INSERT INTO `customers` (`customer_id`, `sch_id`, `customer_name`, `father_name`, `mother_name`, `address`, `present_address`, `age`, `mobile`, `pic`, `nid`, `cus_type_id`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (94, 22, `সজীব` `খান`, NULL, NULL, NULL, NULL, NULL, 1929649448, NULL, NULL, 32, 0, `2022-09-27` `08:43:35`, 25, `2022-09-27` `19:43:35`, NULL, NULL, NULL);
INSERT INTO `customers` (`customer_id`, `sch_id`, `customer_name`, `father_name`, `mother_name`, `address`, `present_address`, `age`, `mobile`, `pic`, `nid`, `cus_type_id`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (95, 20, `Ovi`, NULL, NULL, NULL, NULL, NULL, 2147483647, NULL, NULL, 30, 0, `2022-09-28` `08:55:05`, 23, `2022-09-28` `19:55:05`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: employee
#

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `salary` int(11) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `balance` double unsigned DEFAULT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`employee_id`),
  KEY `sch_id` (`sch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `employee` (`employee_id`, `sch_id`, `name`, `salary`, `age`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, `New` `Employee`, 5000, 20, NULL, `2022-09-27` `12:45:29`, 26, `2022-09-27` `11:45:29`, NULL, NULL, NULL);
INSERT INTO `employee` (`employee_id`, `sch_id`, `name`, `salary`, `age`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 22, `Murad`, 4000, 35, 5000, `2022-09-28` `08:33:10`, 25, `2022-09-28` `19:37:43`, 25, NULL, NULL);
INSERT INTO `employee` (`employee_id`, `sch_id`, `name`, `salary`, `age`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 22, `MD`.` TARIQUL` `ISLAM`, 4500, 30, 2000, `2022-09-28` `08:33:19`, 25, `2022-09-28` `19:33:19`, NULL, NULL, NULL);
INSERT INTO `employee` (`employee_id`, `sch_id`, `name`, `salary`, `age`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 20, `Emon`, 4000, 19, NULL, `2022-09-29` `08:45:08`, 23, `2022-09-29` `19:45:08`, NULL, NULL, NULL);
INSERT INTO `employee` (`employee_id`, `sch_id`, `name`, `salary`, `age`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 20, `Mukul`, 3000, 18, NULL, `2022-09-29` `08:47:20`, 23, `2022-09-29` `19:47:20`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: gen_settings
#

DROP TABLE IF EXISTS `gen_settings`;

CREATE TABLE `gen_settings` (
  `settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `label` varchar(155) NOT NULL,
  `value` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`settings_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `gen_settings_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=latin1;

INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (191, 20, `barcode_img_size`, 100, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (192, 20, `barcode_type`, `C128A`, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (193, 20, `business_type`, `Ownership` `business`, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (194, 20, `currency`, `BDT`, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (195, 20, `currency_before_symbol`, `৳`, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (196, 20, `currency_after_symbol`, `/-`, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (197, 20, `running_year`, `2018-2019`, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (198, 20, `disable_frontend`, 0, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (199, 20, `phone_code`, 880, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (200, 20, `country`, `Bangladesh`, `2022-09-26` `19:23:15`, 0, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (201, 21, `barcode_img_size`, 100, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (202, 21, `barcode_type`, `C128A`, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (203, 21, `business_type`, `Ownership` `business`, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (204, 21, `currency`, `BDT`, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (205, 21, `currency_before_symbol`, `৳`, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (206, 21, `currency_after_symbol`, `/-`, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (207, 21, `running_year`, `2018-2019`, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (208, 21, `disable_frontend`, 0, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (209, 21, `phone_code`, 880, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (210, 21, `country`, `Bangladesh`, `2022-09-26` `19:25:24`, 0, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (211, 22, `barcode_img_size`, 100, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (212, 22, `barcode_type`, `C128A`, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (213, 22, `business_type`, `Ownership` `business`, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (214, 22, `currency`, `BDT`, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (215, 22, `currency_before_symbol`, `৳`, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (216, 22, `currency_after_symbol`, `/-`, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (217, 22, `running_year`, `2018-2019`, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (218, 22, `disable_frontend`, 0, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (219, 22, `phone_code`, 880, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (220, 22, `country`, `Bangladesh`, `2022-09-26` `19:49:10`, 0, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (221, 23, `barcode_img_size`, 100, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (222, 23, `barcode_type`, `C128A`, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (223, 23, `business_type`, `Ownership` `business`, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (224, 23, `currency`, `BDT`, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (225, 23, `currency_before_symbol`, `৳`, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (226, 23, `currency_after_symbol`, `/-`, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (227, 23, `running_year`, `2018-2019`, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (228, 23, `disable_frontend`, 0, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (229, 23, `phone_code`, 880, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (230, 23, `country`, `Bangladesh`, `2022-09-27` `09:58:18`, 0, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (231, 24, `barcode_img_size`, 100, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (232, 24, `barcode_type`, `C128A`, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (233, 24, `business_type`, `Ownership` `business`, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (234, 24, `currency`, `BDT`, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (235, 24, `currency_before_symbol`, `৳`, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (236, 24, `currency_after_symbol`, `/-`, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (237, 24, `running_year`, `2018-2019`, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (238, 24, `disable_frontend`, 0, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (239, 24, `phone_code`, 880, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);
INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (240, 24, `country`, `Bangladesh`, `2022-10-01` `11:22:37`, 0, NULL, `2022-10-01` `11:22:37`, NULL, NULL);


#
# TABLE STRUCTURE FOR: gen_settings_super
#

DROP TABLE IF EXISTS `gen_settings_super`;

CREATE TABLE `gen_settings_super` (
  `settings_id_sup` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(155) NOT NULL,
  `value` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`settings_id_sup`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `gen_settings_super` (`settings_id_sup`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (1, `loading_message`, `Please wait until it is` `processing`.., `2022-09-27` `10:55:34`, 0, NULL, `2022-09-27` `10:55:34`, NULL, NULL);
INSERT INTO `gen_settings_super` (`settings_id_sup`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (2, `site_title`, `Shohoz Hishab | Accounting management` `system`, `2022-09-27` `10:55:53`, 0, NULL, `2022-09-27` `10:55:53`, NULL, NULL);


#
# TABLE STRUCTURE FOR: invoice
#

DROP TABLE IF EXISTS `invoice`;

CREATE TABLE `invoice` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `pymnt_type_id` int(11) DEFAULT NULL,
  `customer_name` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` double unsigned NOT NULL,
  `entire_sale_discount` int(11) DEFAULT NULL,
  `vat` int(11) DEFAULT NULL,
  `final_amount` double unsigned NOT NULL,
  `profit` double NOT NULL COMMENT 'profit on the sale',
  `nagad_paid` double unsigned DEFAULT NULL,
  `bank_paid` double unsigned DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `chaque_paid` double unsigned DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `due` double unsigned DEFAULT NULL,
  `creation_timestamp` int(11) DEFAULT NULL,
  `payment_timestamp` longtext COLLATE utf8_unicode_ci,
  `payment_method` longtext COLLATE utf8_unicode_ci,
  `payment_details` longtext COLLATE utf8_unicode_ci,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `year` longtext COLLATE utf8_unicode_ci,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`invoice_id`),
  KEY `sch_id` (`sch_id`),
  KEY `student_id` (`customer_id`),
  KEY `pymnt_type_id` (`pymnt_type_id`),
  CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON UPDATE CASCADE,
  CONSTRAINT `invoice_ibfk_3` FOREIGN KEY (`pymnt_type_id`) REFERENCES `payment_type` (`pymnt_type_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `invoice` (`invoice_id`, `sch_id`, `customer_id`, `pymnt_type_id`, `customer_name`, `amount`, `entire_sale_discount`, `vat`, `final_amount`, `profit`, `nagad_paid`, `bank_paid`, `bank_id`, `chaque_paid`, `chaque_id`, `due`, `creation_timestamp`, `payment_timestamp`, `payment_method`, `payment_details`, `status`, `timestamp`, `year`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (1, 23, 92, NULL, NULL, 420, 2, 2, `419`.`83`, `199`.`83`, 0, 0, 0, 0, NULL, `419`.`83`, NULL, NULL, NULL, NULL, 1, `2022-09-27` `10:57:09`, NULL, `2022-09-26` `11:57:09`, 26, 26, `2022-09-27` `10:57:09`, NULL, NULL);
INSERT INTO `invoice` (`invoice_id`, `sch_id`, `customer_id`, `pymnt_type_id`, `customer_name`, `amount`, `entire_sale_discount`, `vat`, `final_amount`, `profit`, `nagad_paid`, `bank_paid`, `bank_id`, `chaque_paid`, `chaque_id`, `due`, `creation_timestamp`, `payment_timestamp`, `payment_method`, `payment_details`, `status`, `timestamp`, `year`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (2, 23, 92, NULL, NULL, 200, 0, 0, 200, 80, 0, 0, 0, 200, 1, 0, NULL, NULL, NULL, NULL, 1, `2022-09-27` `11:05:54`, NULL, `2022-09-27` `12:05:54`, 26, 26, `2022-09-27` `11:05:54`, NULL, NULL);
INSERT INTO `invoice` (`invoice_id`, `sch_id`, `customer_id`, `pymnt_type_id`, `customer_name`, `amount`, `entire_sale_discount`, `vat`, `final_amount`, `profit`, `nagad_paid`, `bank_paid`, `bank_id`, `chaque_paid`, `chaque_id`, `due`, `creation_timestamp`, `payment_timestamp`, `payment_method`, `payment_details`, `status`, `timestamp`, `year`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (3, 22, 93, NULL, NULL, 7600, 0, 2, 7752, 2752, 7752, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, `2022-09-27` `20:03:33`, NULL, `2022-09-27` `09:03:33`, 25, 25, `2022-09-27` `20:03:34`, NULL, NULL);
INSERT INTO `invoice` (`invoice_id`, `sch_id`, `customer_id`, `pymnt_type_id`, `customer_name`, `amount`, `entire_sale_discount`, `vat`, `final_amount`, `profit`, `nagad_paid`, `bank_paid`, `bank_id`, `chaque_paid`, `chaque_id`, `due`, `creation_timestamp`, `payment_timestamp`, `payment_method`, `payment_details`, `status`, `timestamp`, `year`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (4, 20, 90, NULL, NULL, `548`.`8`, 0, 3, `565`.`26`, `165`.`26`, 565, 0, 0, 0, NULL, `0`.`26`, NULL, NULL, NULL, NULL, 1, `2022-09-27` `20:10:14`, NULL, `2022-09-27` `09:10:14`, 23, 23, `2022-09-27` `20:10:14`, NULL, NULL);
INSERT INTO `invoice` (`invoice_id`, `sch_id`, `customer_id`, `pymnt_type_id`, `customer_name`, `amount`, `entire_sale_discount`, `vat`, `final_amount`, `profit`, `nagad_paid`, `bank_paid`, `bank_id`, `chaque_paid`, `chaque_id`, `due`, `creation_timestamp`, `payment_timestamp`, `payment_method`, `payment_details`, `status`, `timestamp`, `year`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (5, 20, NULL, NULL, `Rana`, `274`.`4`, 0, 3, `282`.`63`, `132`.`63`, `282`.`63`, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 1, `2022-09-28` `19:33:29`, NULL, `2022-09-28` `08:33:29`, 23, 23, `2022-09-28` `19:33:29`, NULL, NULL);


#
# TABLE STRUCTURE FOR: invoice_item
#

DROP TABLE IF EXISTS `invoice_item`;

CREATE TABLE `invoice_item` (
  `inv_item` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `sch_id` int(11) NOT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `title` varchar(155) DEFAULT NULL COMMENT 'It will be used, if prod_id is not inserted into the table.',
  `price` double unsigned NOT NULL,
  `quantity` int(11) unsigned NOT NULL,
  `total_price` double unsigned NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `final_price` double unsigned NOT NULL,
  `profit` double NOT NULL COMMENT 'profit on individual product',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) unsigned DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`inv_item`),
  KEY `invoice_id` (`invoice_id`),
  KEY `inv_exist_item_id` (`prod_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `invoice_item_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`) ON UPDATE CASCADE,
  CONSTRAINT `invoice_item_ibfk_2` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `invoice_item_ibfk_3` FOREIGN KEY (`prod_id`) REFERENCES `products` (`prod_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_item` (`inv_item`, `invoice_id`, `sch_id`, `prod_id`, `title`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `profit`, `date`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (1, 1, 23, 3, NULL, 100, 2, 200, 0, 200, 100, `2022-09-27` `10:57:09`, `2022-09-26` `11:57:09`, 26, NULL, `2022-09-27` `10:57:09`, NULL, NULL);
INSERT INTO `invoice_item` (`inv_item`, `invoice_id`, `sch_id`, `prod_id`, `title`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `profit`, `date`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (2, 1, 23, 1, NULL, 100, 1, 100, 0, 100, 40, `2022-09-27` `10:57:09`, `2022-09-26` `11:57:09`, 26, NULL, `2022-09-27` `10:57:09`, NULL, NULL);
INSERT INTO `invoice_item` (`inv_item`, `invoice_id`, `sch_id`, `prod_id`, `title`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `profit`, `date`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (3, 1, 23, 2, NULL, 120, 1, 120, 0, 120, 60, `2022-09-27` `10:57:09`, `2022-09-26` `11:57:09`, 26, NULL, `2022-09-27` `10:57:09`, NULL, NULL);
INSERT INTO `invoice_item` (`inv_item`, `invoice_id`, `sch_id`, `prod_id`, `title`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `profit`, `date`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (4, 2, 23, 1, NULL, 100, 2, 200, 0, 200, 80, `2022-09-27` `11:05:54`, `2022-09-27` `12:05:54`, 26, NULL, `2022-09-27` `11:05:54`, NULL, NULL);
INSERT INTO `invoice_item` (`inv_item`, `invoice_id`, `sch_id`, `prod_id`, `title`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `profit`, `date`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (5, 3, 22, 6, NULL, 4000, 2, 8000, 5, 7600, 2600, `2022-09-27` `20:03:33`, `2022-09-27` `09:03:33`, 25, NULL, `2022-09-27` `20:03:34`, NULL, NULL);
INSERT INTO `invoice_item` (`inv_item`, `invoice_id`, `sch_id`, `prod_id`, `title`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `profit`, `date`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (6, 4, 20, 4, NULL, 280, 2, 560, 2, `548`.`8`, `148`.`8`, `2022-09-27` `20:10:14`, `2022-09-27` `09:10:14`, 23, NULL, `2022-09-27` `20:10:14`, NULL, NULL);
INSERT INTO `invoice_item` (`inv_item`, `invoice_id`, `sch_id`, `prod_id`, `title`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `profit`, `date`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (7, 5, 20, 9, NULL, 280, 1, 280, 2, `274`.`4`, `124`.`4`, `2022-09-28` `19:33:29`, `2022-09-28` `08:33:29`, 23, NULL, `2022-09-28` `19:33:29`, NULL, NULL);


#
# TABLE STRUCTURE FOR: lc
#

DROP TABLE IF EXISTS `lc`;

CREATE TABLE `lc` (
  `lc_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `lc_name` varchar(155) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `amount` float unsigned NOT NULL,
  `rest_balance` float NOT NULL COMMENT 'Rest of the balance of the LC',
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) NOT NULL,
  `deletedRole` int(11) NOT NULL,
  PRIMARY KEY (`lc_id`),
  KEY `sch_id` (`sch_id`),
  KEY `bank_id` (`bank_id`),
  CONSTRAINT `lc_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `lc_ibfk_2` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`bank_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: ledger
#

DROP TABLE IF EXISTS `ledger`;

CREATE TABLE `ledger` (
  `ledg_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double unsigned NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledg_id`),
  KEY `sch_id` (`sch_id`),
  KEY `customer_id` (`customer_id`),
  KEY `inv_id` (`invoice_id`),
  KEY `trans_id` (`trans_id`),
  KEY `rtn_sale_id` (`rtn_sale_id`),
  CONSTRAINT `ledger_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_ibfk_3` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_ibfk_4` FOREIGN KEY (`trans_id`) REFERENCES `transaction` (`trans_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 92, NULL, NULL, NULL, NULL, `Previous` `balance`, `Dr`., 0, 0, `2022-09-26` `10:59:29`, 23, `2022-09-27` `09:59:29`, NULL, NULL, NULL);
INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 23, 92, 1, NULL, NULL, NULL, `Sales Cash` `Due`, `Dr`., `419`.`83`, `419`.`83`, `2022-09-26` `11:57:09`, 26, `2022-09-27` `10:57:09`, NULL, NULL, NULL);
INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 23, 92, NULL, 140, NULL, NULL, `pay`, `Cr`., 300, `119`.`83`, `2022-09-27` `12:03:43`, 26, `2022-09-27` `11:03:43`, NULL, NULL, NULL);
INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 23, 92, 2, NULL, NULL, NULL, `Sales Cash` `Due`, `Dr`., 200, `319`.`83`, `2022-09-27` `12:05:54`, 26, `2022-09-27` `11:05:54`, NULL, NULL, NULL);
INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 23, 92, NULL, NULL, NULL, 1, `Chaque Cash` `Approved`, `Cr`., 200, `119`.`83`, `2022-09-27` `11:06:31`, 0, `2022-09-27` `11:06:31`, NULL, NULL, NULL);
INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 22, 93, 3, NULL, NULL, NULL, `Sales Cash` `Due`, `Dr`., 7752, 7752, `2022-09-27` `09:03:34`, 25, `2022-09-27` `20:03:34`, NULL, NULL, NULL);
INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (7, 22, 93, 3, NULL, NULL, NULL, `Sales Cash` `Pay`, `Cr`., 7752, 0, `2022-09-27` `09:03:34`, 25, `2022-09-27` `20:03:34`, NULL, NULL, NULL);
INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (8, 20, 90, 4, NULL, NULL, NULL, `Sales Cash` `Due`, `Dr`., `565`.`26`, `565`.`26`, `2022-09-27` `09:10:14`, 23, `2022-09-27` `20:10:14`, NULL, NULL, NULL);
INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (9, 20, 90, 4, NULL, NULL, NULL, `Sales Cash` `Pay`, `Cr`., 565, `0`.`25999999999999`, `2022-09-27` `09:10:14`, 23, `2022-09-27` `20:10:14`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_bank
#

DROP TABLE IF EXISTS `ledger_bank`;

CREATE TABLE `ledger_bank` (
  `ledgBank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` int(11) NOT NULL,
  `sch_id` int(11) NOT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double unsigned NOT NULL,
  `rest_balance` double unsigned NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledgBank_id`),
  KEY `bank_id` (`bank_id`),
  KEY `sch_id` (`sch_id`),
  KEY `money_receipt_id` (`money_receipt_id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `trans_id` (`trans_id`),
  KEY `rtn_purchase_id` (`rtn_purchase_id`),
  KEY `rtn_sale_id` (`rtn_sale_id`),
  CONSTRAINT `ledger_bank_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`bank_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_bank_ibfk_2` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_bank_ibfk_3` FOREIGN KEY (`money_receipt_id`) REFERENCES `money_receipt` (`money_receipt_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_bank_ibfk_4` FOREIGN KEY (`purchase_id`) REFERENCES `purchase` (`purchase_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_bank_ibfk_5` FOREIGN KEY (`trans_id`) REFERENCES `transaction` (`trans_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_bank` (`ledgBank_id`, `bank_id`, `sch_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 34, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Deposit`, `Dr`., 20000, 20000, `2022-09-27` `12:05:17`, 0, `2022-09-27` `11:05:17`, NULL, NULL, NULL);
INSERT INTO `ledger_bank` (`ledgBank_id`, `bank_id`, `sch_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 34, 23, NULL, NULL, 146, NULL, NULL, NULL, NULL, `Withdraw`, `Cr`., 10000, 10000, `2022-09-27` `12:08:30`, 26, `2022-09-27` `11:08:30`, NULL, NULL, NULL);
INSERT INTO `ledger_bank` (`ledgBank_id`, `bank_id`, `sch_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 35, 23, NULL, NULL, 146, NULL, NULL, NULL, NULL, `werew`, `Dr`., 10000, 10000, `2022-09-27` `12:08:30`, 26, `2022-09-27` `11:08:30`, NULL, NULL, NULL);
INSERT INTO `ledger_bank` (`ledgBank_id`, `bank_id`, `sch_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 36, 22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Deposit`, `Dr`., 100000, 100000, `2022-09-28` `08:25:54`, 0, `2022-09-28` `19:25:54`, NULL, NULL, NULL);
INSERT INTO `ledger_bank` (`ledgBank_id`, `bank_id`, `sch_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 37, 22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Deposit`, `Dr`., 50000, 50000, `2022-09-28` `08:26:15`, 0, `2022-09-28` `19:26:15`, NULL, NULL, NULL);
INSERT INTO `ledger_bank` (`ledgBank_id`, `bank_id`, `sch_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 33, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Deposit`, `Dr`., 30000, 30000, `2022-09-28` `08:27:13`, 0, `2022-09-28` `19:27:13`, NULL, NULL, NULL);
INSERT INTO `ledger_bank` (`ledgBank_id`, `bank_id`, `sch_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (7, 33, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Withdraw`, `Cr`., 5000, 25000, `2022-09-28` `08:28:22`, 0, `2022-09-28` `19:28:22`, NULL, NULL, NULL);
INSERT INTO `ledger_bank` (`ledgBank_id`, `bank_id`, `sch_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (8, 36, 22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Withdraw`, `Cr`., 10000, 90000, `2022-09-28` `08:29:42`, 0, `2022-09-28` `19:29:42`, NULL, NULL, NULL);
INSERT INTO `ledger_bank` (`ledgBank_id`, `bank_id`, `sch_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (9, 37, 22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Withdraw`, `Cr`., 5000, 45000, `2022-09-28` `08:30:02`, 0, `2022-09-28` `19:30:02`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_capital
#

DROP TABLE IF EXISTS `ledger_capital`;

CREATE TABLE `ledger_capital` (
  `capital_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`capital_id`),
  KEY `sch_id` (`sch_id`),
  KEY `trans_id` (`trans_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_capital` (`capital_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (54, 20, NULL, `Invest`, `Cr`., 20000, `-20000`, `2022-09-26` `09:05:46`, 23, `2022-09-26` `20:05:46`, NULL, NULL, NULL);
INSERT INTO `ledger_capital` (`capital_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (55, 23, NULL, `first` `money`, `Cr`., 50000, `-50000`, `2022-09-26` `10:59:18`, 26, `2022-09-27` `09:59:18`, NULL, NULL, NULL);
INSERT INTO `ledger_capital` (`capital_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (56, 22, NULL, `Start` `Business`, `Cr`., 1000000, `-1000000`, `2022-09-27` `08:54:30`, 25, `2022-09-27` `19:54:30`, NULL, NULL, NULL);
INSERT INTO `ledger_capital` (`capital_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (57, 22, NULL, Existing Employee (MD. TARIQUL ISLAM) is added with existing balance, `Cr`., 2000, `-1002000`, `2022-09-28` `08:33:19`, 25, `2022-09-28` `19:33:19`, NULL, NULL, NULL);
INSERT INTO `ledger_capital` (`capital_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (58, 21, NULL, `Start With` `This`, `Cr`., 50000, `-50000`, `2022-10-03` `05:32:40`, 24, `2022-10-03` `17:32:40`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_discount
#

DROP TABLE IF EXISTS `ledger_discount`;

CREATE TABLE `ledger_discount` (
  `discount_ledg_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double unsigned DEFAULT NULL,
  `rest_balance` double DEFAULT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`discount_ledg_id`),
  KEY `sch_id` (`sch_id`),
  KEY `inv_id` (`invoice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_discount` (`discount_ledg_id`, `sch_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 1, `Sale` `discount`, `Dr`., `0`.`17000000000002`, `0`.`17000000000002`, `2022-09-26` `11:57:09`, 0, `2022-09-27` `10:57:09`, NULL, NULL, NULL);
INSERT INTO `ledger_discount` (`discount_ledg_id`, `sch_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 22, 3, `Sale` `discount`, `Dr`., 248, 248, `2022-09-27` `09:03:33`, 0, `2022-09-27` `20:03:33`, NULL, NULL, NULL);
INSERT INTO `ledger_discount` (`discount_ledg_id`, `sch_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 20, 4, `Sale` `discount`, `Dr`., 0, `-5`.`26`, `2022-09-27` `09:10:14`, 0, `2022-09-27` `20:10:14`, NULL, NULL, NULL);
INSERT INTO `ledger_discount` (`discount_ledg_id`, `sch_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 20, 5, `Sale` `discount`, `Dr`., 0, `-7`.`89`, `2022-09-28` `08:33:29`, 0, `2022-09-28` `19:33:29`, NULL, NULL, NULL);
INSERT INTO `ledger_discount` (`discount_ledg_id`, `sch_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 21, 6, `Sale` `discount`, `Dr`., `2059`.`2`, `2059`.`2`, `2022-09-29` `06:30:31`, 0, `2022-09-29` `17:30:31`, NULL, NULL, NULL);
INSERT INTO `ledger_discount` (`discount_ledg_id`, `sch_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 21, 7, `Sale` `discount`, `Dr`., 0, `-1270`.`8`, `2022-10-01` `06:36:37`, 0, `2022-10-01` `17:36:37`, NULL, NULL, NULL);
INSERT INTO `ledger_discount` (`discount_ledg_id`, `sch_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (7, 21, 8, `Sale` `discount`, `Dr`., `479`.`98`, `-790`.`82`, `2022-10-01` `06:43:56`, 0, `2022-10-01` `17:43:56`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_employee
#

DROP TABLE IF EXISTS `ledger_employee`;

CREATE TABLE `ledger_employee` (
  `ledg_emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double unsigned NOT NULL,
  `rest_balance` double unsigned NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledg_emp_id`),
  KEY `sch_id` (`sch_id`),
  KEY `trans_id` (`trans_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_employee` (`ledg_emp_id`, `sch_id`, `employee_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 22, 4, NULL, NULL, `Employee last` `balance`, `Dr`., 2000, 2000, `2022-09-28` `08:33:19`, 25, `2022-09-28` `19:33:19`, NULL, NULL, NULL);
INSERT INTO `ledger_employee` (`ledg_emp_id`, `sch_id`, `employee_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 22, 3, 152, NULL, `July`, `Dr`., 5000, 5000, `2022-09-28` `08:37:43`, 25, `2022-09-28` `19:37:43`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_expense
#

DROP TABLE IF EXISTS `ledger_expense`;

CREATE TABLE `ledger_expense` (
  `ledg_exp_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `memo_number` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double unsigned NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledg_exp_id`),
  KEY `sch_id` (`sch_id`),
  KEY `inv_id` (`memo_number`),
  KEY `trans_id` (`trans_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_expense` (`ledg_exp_id`, `sch_id`, `memo_number`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 5435345, 143, NULL, `sfs`, `Dr`., 20, 20, `2022-09-27` `12:06:59`, 26, `2022-09-27` `11:06:59`, NULL, NULL, NULL);
INSERT INTO `ledger_expense` (`ledg_exp_id`, `sch_id`, `memo_number`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 22, 77, 150, NULL, `Decoration`, `Dr`., 40000, 40000, `2022-09-28` `08:34:32`, 25, `2022-09-28` `19:34:32`, NULL, NULL, NULL);
INSERT INTO `ledger_expense` (`ledg_exp_id`, `sch_id`, `memo_number`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 20, 2147483647, 153, NULL, `ioh`, `Dr`., 100, 100, `2022-09-28` `08:41:43`, 23, `2022-09-28` `19:41:43`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_loan
#

DROP TABLE IF EXISTS `ledger_loan`;

CREATE TABLE `ledger_loan` (
  `ledg_loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `loan_pro_id` int(11) NOT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double unsigned NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledg_loan_id`),
  KEY `sch_id` (`sch_id`),
  KEY `loan_pro_id` (`loan_pro_id`),
  KEY `money_receipt_id` (`money_receipt_id`),
  KEY `trans_id` (`trans_id`),
  CONSTRAINT `ledger_loan_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_loan_ibfk_2` FOREIGN KEY (`loan_pro_id`) REFERENCES `loan_provider` (`loan_pro_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_loan_ibfk_3` FOREIGN KEY (`money_receipt_id`) REFERENCES `money_receipt` (`money_receipt_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_loan_ibfk_4` FOREIGN KEY (`trans_id`) REFERENCES `transaction` (`trans_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_loan` (`ledg_loan_id`, `sch_id`, `loan_pro_id`, `money_receipt_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (83, 20, 48, NULL, 139, NULL, `Loan`, `Cr`., 100000, `-100000`, `2022-09-26` `09:03:02`, 23, `2022-09-26` `20:03:02`, NULL, NULL, NULL);
INSERT INTO `ledger_loan` (`ledg_loan_id`, `sch_id`, `loan_pro_id`, `money_receipt_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (84, 23, 50, NULL, NULL, NULL, `Previous` `balance`, `Dr`., 0, 0, `2022-09-26` `10:59:35`, 23, `2022-09-27` `09:59:35`, NULL, NULL, NULL);
INSERT INTO `ledger_loan` (`ledg_loan_id`, `sch_id`, `loan_pro_id`, `money_receipt_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (85, 23, 50, NULL, 142, NULL, `lone`, `Cr`., 20000, `-20000`, `2022-09-27` `12:04:38`, 26, `2022-09-27` `11:04:38`, NULL, NULL, NULL);
INSERT INTO `ledger_loan` (`ledg_loan_id`, `sch_id`, `loan_pro_id`, `money_receipt_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (87, 22, 51, NULL, 148, NULL, `Loan`, `Cr`., 500000, `-500000`, `2022-09-27` `08:56:52`, 25, `2022-09-27` `19:56:52`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_nagodan
#

DROP TABLE IF EXISTS `ledger_nagodan`;

CREATE TABLE `ledger_nagodan` (
  `ledg_nagodan_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `loan_pro_id` int(11) DEFAULT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double unsigned NOT NULL,
  `rest_balance` double unsigned NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledg_nagodan_id`),
  KEY `sch_id` (`sch_id`),
  KEY `customer_id` (`customer_id`),
  KEY `bank_id` (`bank_id`),
  KEY `loan_pro_id` (`loan_pro_id`),
  KEY `money_receipt_id` (`money_receipt_id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `trans_id` (`trans_id`),
  KEY `rtn_purchase_id` (`rtn_purchase_id`),
  KEY `rtn_sale_id` (`rtn_sale_id`),
  CONSTRAINT `ledger_nagodan_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_nagodan_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_nagodan_ibfk_3` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`bank_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_nagodan_ibfk_4` FOREIGN KEY (`loan_pro_id`) REFERENCES `loan_provider` (`loan_pro_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_nagodan_ibfk_5` FOREIGN KEY (`money_receipt_id`) REFERENCES `money_receipt` (`money_receipt_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_nagodan_ibfk_6` FOREIGN KEY (`purchase_id`) REFERENCES `purchase` (`purchase_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_nagodan_ibfk_7` FOREIGN KEY (`trans_id`) REFERENCES `transaction` (`trans_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (274, 20, NULL, NULL, NULL, NULL, NULL, 139, NULL, NULL, NULL, NULL, `Loan`, `Dr`., 100000, 100000, `2022-09-26` `09:03:02`, 23, `2022-09-26` `20:03:02`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (275, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Invest`, `Dr`., 20000, 120000, `2022-09-26` `09:05:46`, 23, `2022-09-26` `20:05:46`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (276, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `first` `money`, `Dr`., 50000, 50000, `2022-09-26` `10:59:18`, 26, `2022-09-27` `09:59:18`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (277, 23, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Cr`., 8000, 42000, `2022-09-26` `11:47:55`, 26, `2022-09-27` `10:47:55`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (278, 23, NULL, NULL, NULL, NULL, NULL, 140, NULL, NULL, NULL, NULL, `pay`, `Dr`., 300, 42300, `2022-09-27` `12:03:43`, 26, `2022-09-27` `11:03:43`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (279, 23, NULL, NULL, NULL, NULL, NULL, 141, NULL, NULL, NULL, NULL, `pay`, `Cr`., 500, 41800, `2022-09-27` `12:04:19`, 26, `2022-09-27` `11:04:19`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (280, 23, NULL, NULL, NULL, NULL, NULL, 142, NULL, NULL, NULL, NULL, `lone`, `Dr`., 20000, 61800, `2022-09-27` `12:04:38`, 26, `2022-09-27` `11:04:38`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (281, 23, NULL, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Deposit`, `Cr`., 20000, 41800, `2022-09-27` `12:05:17`, 0, `2022-09-27` `11:05:17`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (282, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, `Chaque Cash` `Approved`, `Dr`., 200, 42000, `2022-09-27` `11:06:31`, 0, `2022-09-27` `11:06:31`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (283, 23, NULL, NULL, NULL, NULL, NULL, 143, NULL, NULL, NULL, NULL, `sfs`, `Cr`., 20, 41980, `2022-09-27` `12:06:59`, 26, `2022-09-27` `11:06:59`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (284, 23, NULL, NULL, NULL, NULL, NULL, 144, NULL, NULL, NULL, NULL, `gtdg`, `Dr`., 50, 42030, `2022-09-27` `12:07:22`, 26, `2022-09-27` `11:07:22`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (285, 23, NULL, NULL, NULL, NULL, NULL, 145, NULL, NULL, NULL, NULL, `erreyre`, `Cr`., 8, 42022, `2022-09-27` `12:07:46`, 26, `2022-09-27` `11:07:46`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (287, 20, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Cr`., 2000, 118000, `2022-09-27` `08:25:56`, 23, `2022-09-27` `19:25:56`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (288, 20, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Cr`., 3000, 115000, `2022-09-27` `08:28:19`, 23, `2022-09-27` `19:28:19`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (289, 22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Start` `Business`, `Dr`., 1000000, 1000000, `2022-09-27` `08:54:30`, 25, `2022-09-27` `19:54:30`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (290, 22, NULL, NULL, NULL, NULL, NULL, 148, NULL, NULL, NULL, NULL, `Loan`, `Dr`., 500000, 1500000, `2022-09-27` `08:56:52`, 25, `2022-09-27` `19:56:52`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (291, 22, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Cr`., 125000, 1375000, `2022-09-27` `09:00:02`, 25, `2022-09-27` `20:00:02`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (292, 22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, `Sales Cash` `Pay`, `Dr`., 7752, 1382752, `2022-09-27` `09:03:34`, 25, `2022-09-27` `20:03:34`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (293, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, `Sales Cash` `Pay`, `Dr`., 565, 115565, `2022-09-27` `09:10:14`, 23, `2022-09-27` `20:10:14`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (296, 20, NULL, NULL, NULL, NULL, 11, NULL, NULL, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Cr`., 2250, 113315, `2022-09-28` `08:13:33`, 23, `2022-09-28` `19:13:33`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (297, 22, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Deposit`, `Cr`., 100000, 1282752, `2022-09-28` `08:25:54`, 0, `2022-09-28` `19:25:54`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (298, 22, NULL, 37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Deposit`, `Cr`., 50000, 1232752, `2022-09-28` `08:26:15`, 0, `2022-09-28` `19:26:15`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (299, 20, NULL, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Deposit`, `Cr`., 30000, 83315, `2022-09-28` `08:27:13`, 0, `2022-09-28` `19:27:13`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (300, 20, NULL, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Withdraw`, `Dr`., 5000, 88315, `2022-09-28` `08:28:22`, 0, `2022-09-28` `19:28:22`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (301, 22, NULL, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Withdraw`, `Dr`., 10000, 1242752, `2022-09-28` `08:29:42`, 0, `2022-09-28` `19:29:42`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (302, 22, NULL, 37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Bank Cash` `Withdraw`, `Dr`., 5000, 1247752, `2022-09-28` `08:30:02`, 0, `2022-09-28` `19:30:02`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (303, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, `Sales Cash` `Pay`, `Dr`., `282`.`63`, `88597`.`63`, `2022-09-28` `08:33:29`, 23, `2022-09-28` `19:33:29`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (304, 22, NULL, NULL, NULL, NULL, NULL, 150, NULL, NULL, NULL, NULL, `Decoration`, `Cr`., 40000, 1207752, `2022-09-28` `08:34:32`, 25, `2022-09-28` `19:34:32`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (305, 22, NULL, NULL, NULL, NULL, NULL, 151, NULL, NULL, NULL, NULL, `iudfugigju`, `Dr`., 20000, 1227752, `2022-09-28` `08:35:59`, 25, `2022-09-28` `19:35:59`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (306, 22, NULL, NULL, NULL, NULL, NULL, 152, NULL, NULL, NULL, NULL, `July`, `Cr`., 5000, 1222752, `2022-09-28` `08:37:43`, 25, `2022-09-28` `19:37:43`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (307, 20, NULL, NULL, NULL, NULL, NULL, 153, NULL, NULL, NULL, NULL, `ioh`, `Cr`., 100, `88497`.`63`, `2022-09-28` `08:41:43`, 23, `2022-09-28` `19:41:43`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (308, 22, NULL, NULL, NULL, NULL, NULL, 154, NULL, NULL, NULL, NULL, `Vat`, `Cr`., 152, 1222600, `2022-09-28` `08:41:47`, 25, `2022-09-28` `19:41:47`, NULL, NULL, NULL);
INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (309, 21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `Start With` `This`, `Dr`., 50000, 50000, `2022-10-03` `05:32:40`, 24, `2022-10-03` `17:32:40`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_other_sales
#

DROP TABLE IF EXISTS `ledger_other_sales`;

CREATE TABLE `ledger_other_sales` (
  `ledg_oth_sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double unsigned NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledg_oth_sales_id`),
  KEY `sch_id` (`sch_id`),
  KEY `trans_id` (`trans_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_other_sales` (`ledg_oth_sales_id`, `sch_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 144, NULL, `gtdg`, `Dr`., 50, `2022-09-27` `12:07:22`, 26, `2022-09-27` `11:07:22`, NULL, NULL, NULL);
INSERT INTO `ledger_other_sales` (`ledg_oth_sales_id`, `sch_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 22, 151, NULL, `iudfugigju`, `Dr`., 20000, `2022-09-28` `08:35:59`, 25, `2022-09-28` `19:35:59`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_profit
#

DROP TABLE IF EXISTS `ledger_profit`;

CREATE TABLE `ledger_profit` (
  `profit_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`profit_id`),
  KEY `sch_id` (`sch_id`),
  KEY `trans_id` (`invoice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_profit` (`profit_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 1, NULL, `Sales profit` `get`, `Cr`., 200, `-191`.`6`, `2022-09-26` `11:57:09`, 26, `2022-09-27` `10:57:09`, NULL, NULL, NULL);
INSERT INTO `ledger_profit` (`profit_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 23, 2, NULL, `Sales profit` `get`, `Cr`., 80, `-271`.`6`, `2022-09-27` `12:05:54`, 26, `2022-09-27` `11:05:54`, NULL, NULL, NULL);
INSERT INTO `ledger_profit` (`profit_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 22, 3, NULL, `Sales profit` `get`, `Cr`., 2600, `-2600`, `2022-09-27` `09:03:34`, 25, `2022-09-27` `20:03:34`, NULL, NULL, NULL);
INSERT INTO `ledger_profit` (`profit_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 20, 4, NULL, `Sales profit` `get`, `Cr`., `148`.`8`, `-148`.`8`, `2022-09-27` `09:10:14`, 23, `2022-09-27` `20:10:14`, NULL, NULL, NULL);
INSERT INTO `ledger_profit` (`profit_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 20, 5, NULL, `Sales profit` `get`, `Cr`., `124`.`4`, `-273`.`2`, `2022-09-28` `08:33:29`, 23, `2022-09-28` `19:33:29`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_purchase
#

DROP TABLE IF EXISTS `ledger_purchase`;

CREATE TABLE `ledger_purchase` (
  `ledgPurch_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledgPurch_id`),
  KEY `sch_id` (`sch_id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `rtn_purchase_id` (`rtn_purchase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_purchase` (`ledgPurch_id`, `sch_id`, `purchase_id`, `rtn_purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 1, NULL, `New purchase` `amount`, `Dr`., 8500, 8500, `2022-09-26` `11:47:54`, 26, `2022-09-27` `10:47:54`, NULL, NULL, NULL);
INSERT INTO `ledger_purchase` (`ledgPurch_id`, `sch_id`, `purchase_id`, `rtn_purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 20, 2, NULL, `New purchase` `amount`, `Dr`., 2000, 2000, `2022-09-27` `08:25:56`, 23, `2022-09-27` `19:25:56`, NULL, NULL, NULL);
INSERT INTO `ledger_purchase` (`ledgPurch_id`, `sch_id`, `purchase_id`, `rtn_purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 20, 3, NULL, `New purchase` `amount`, `Dr`., 3000, 5000, `2022-09-27` `08:28:19`, 23, `2022-09-27` `19:28:19`, NULL, NULL, NULL);
INSERT INTO `ledger_purchase` (`ledgPurch_id`, `sch_id`, `purchase_id`, `rtn_purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 22, 4, NULL, `New purchase` `amount`, `Dr`., 125000, 125000, `2022-09-27` `09:00:02`, 25, `2022-09-27` `20:00:02`, NULL, NULL, NULL);
INSERT INTO `ledger_purchase` (`ledgPurch_id`, `sch_id`, `purchase_id`, `rtn_purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 20, 11, NULL, `New purchase` `amount`, `Dr`., 2250, 7250, `2022-09-28` `08:13:33`, 23, `2022-09-28` `19:13:33`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_sales
#

DROP TABLE IF EXISTS `ledger_sales`;

CREATE TABLE `ledger_sales` (
  `ledgSale_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledgSale_id`),
  KEY `sch_id` (`sch_id`),
  KEY `rtn_sale_id` (`rtn_sale_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_sales` (`ledgSale_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 1, NULL, `New Sale` `amount`, `Cr`., `411`.`83`, `-411`.`83`, `2022-09-26` `11:57:09`, 26, `2022-09-27` `10:57:09`, NULL, NULL, NULL);
INSERT INTO `ledger_sales` (`ledgSale_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 23, 2, NULL, `New Sale` `amount`, `Cr`., 200, `-611`.`83`, `2022-09-27` `12:05:54`, 26, `2022-09-27` `11:05:54`, NULL, NULL, NULL);
INSERT INTO `ledger_sales` (`ledgSale_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 22, 3, NULL, `New Sale` `amount`, `Cr`., 7600, `-7600`, `2022-09-27` `09:03:34`, 25, `2022-09-27` `20:03:34`, NULL, NULL, NULL);
INSERT INTO `ledger_sales` (`ledgSale_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 20, 4, NULL, `New Sale` `amount`, `Cr`., `549`.`26`, `-549`.`26`, `2022-09-27` `09:10:14`, 23, `2022-09-27` `20:10:14`, NULL, NULL, NULL);
INSERT INTO `ledger_sales` (`ledgSale_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 20, 5, NULL, `New Sale` `amount`, `Cr`., `274`.`63`, `-823`.`89`, `2022-09-28` `08:33:29`, 23, `2022-09-28` `19:33:29`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_stock
#

DROP TABLE IF EXISTS `ledger_stock`;

CREATE TABLE `ledger_stock` (
  `stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`stock_id`),
  KEY `sch_id` (`sch_id`),
  KEY `trans_id` (`invoice_id`),
  KEY `purchase_id` (`purchase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, NULL, NULL, 1, `New purchase` `amount`, `Dr`., 8500, 8500, `2022-09-26` `11:47:55`, 26, `2022-09-27` `10:47:55`, NULL, NULL, NULL);
INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 23, 1, NULL, NULL, `Sale` `amount`, `Cr`., 220, 8280, `2022-09-26` `11:57:09`, 26, `2022-09-27` `10:57:09`, NULL, NULL, NULL);
INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 23, 2, NULL, NULL, `Sale` `amount`, `Cr`., 120, 8160, `2022-09-27` `12:05:54`, 26, `2022-09-27` `11:05:54`, NULL, NULL, NULL);
INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 20, NULL, NULL, 2, `New purchase` `amount`, `Dr`., 2000, 2000, `2022-09-27` `08:25:56`, 23, `2022-09-27` `19:25:56`, NULL, NULL, NULL);
INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 20, NULL, NULL, 3, `New purchase` `amount`, `Dr`., 3000, 5000, `2022-09-27` `08:28:19`, 23, `2022-09-27` `19:28:19`, NULL, NULL, NULL);
INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 22, NULL, NULL, 4, `New purchase` `amount`, `Dr`., 125000, 125000, `2022-09-27` `09:00:02`, 25, `2022-09-27` `20:00:02`, NULL, NULL, NULL);
INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (7, 22, 3, NULL, NULL, `Sale` `amount`, `Cr`., 5000, 120000, `2022-09-27` `09:03:34`, 25, `2022-09-27` `20:03:34`, NULL, NULL, NULL);
INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (8, 20, 4, NULL, NULL, `Sale` `amount`, `Cr`., 400, 4600, `2022-09-27` `09:10:14`, 23, `2022-09-27` `20:10:14`, NULL, NULL, NULL);
INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (10, 20, NULL, NULL, 11, `New purchase` `amount`, `Dr`., 2250, 6850, `2022-09-28` `08:13:33`, 23, `2022-09-28` `19:13:33`, NULL, NULL, NULL);
INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (11, 20, 5, NULL, NULL, `Sale` `amount`, `Cr`., 150, 6700, `2022-09-28` `08:33:29`, 23, `2022-09-28` `19:33:29`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_suppliers
#

DROP TABLE IF EXISTS `ledger_suppliers`;

CREATE TABLE `ledger_suppliers` (
  `ledg_sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double unsigned NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledg_sup_id`),
  KEY `sch_id` (`sch_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `money_receipt_id` (`money_receipt_id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `trans_id` (`trans_id`),
  KEY `rtn_purchase_id` (`rtn_purchase_id`),
  CONSTRAINT `ledger_suppliers_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_suppliers_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_suppliers_ibfk_3` FOREIGN KEY (`money_receipt_id`) REFERENCES `money_receipt` (`money_receipt_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_suppliers_ibfk_4` FOREIGN KEY (`purchase_id`) REFERENCES `purchase` (`purchase_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_suppliers_ibfk_5` FOREIGN KEY (`trans_id`) REFERENCES `transaction` (`trans_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 40, NULL, NULL, NULL, NULL, NULL, `Previous` `balance`, `Dr`., 0, 0, `2022-09-26` `10:59:41`, 23, `2022-09-27` `09:59:41`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 23, 40, NULL, 1, NULL, NULL, NULL, `Purchase Cash` `Due`, `Cr`., 8500, `-8500`, `2022-09-26` `11:47:54`, 26, `2022-09-27` `10:47:54`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 23, 40, NULL, 1, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Dr`., 8000, `-500`, `2022-09-26` `11:47:55`, 26, `2022-09-27` `10:47:55`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 23, 40, NULL, NULL, 141, NULL, NULL, `pay`, `Dr`., 500, 0, `2022-09-27` `12:04:19`, 26, `2022-09-27` `11:04:19`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 20, 38, NULL, 2, NULL, NULL, NULL, `Purchase Cash` `Due`, `Cr`., 2000, `-2000`, `2022-09-27` `08:25:56`, 23, `2022-09-27` `19:25:56`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 20, 38, NULL, 2, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Dr`., 2000, 0, `2022-09-27` `08:25:56`, 23, `2022-09-27` `19:25:56`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (7, 20, 38, NULL, 3, NULL, NULL, NULL, `Purchase Cash` `Due`, `Cr`., 3000, `-3000`, `2022-09-27` `08:28:19`, 23, `2022-09-27` `19:28:19`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (8, 20, 38, NULL, 3, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Dr`., 3000, 0, `2022-09-27` `08:28:19`, 23, `2022-09-27` `19:28:19`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (9, 22, 41, NULL, 4, NULL, NULL, NULL, `Purchase Cash` `Due`, `Cr`., 125000, `-125000`, `2022-09-27` `09:00:02`, 25, `2022-09-27` `20:00:02`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (10, 22, 41, NULL, 4, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Dr`., 125000, 0, `2022-09-27` `09:00:02`, 25, `2022-09-27` `20:00:02`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (13, 20, 38, NULL, 11, NULL, NULL, NULL, `Purchase Cash` `Due`, `Cr`., 2250, `-2250`, `2022-09-28` `08:13:33`, 23, `2022-09-28` `19:13:33`, NULL, NULL, NULL);
INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (14, 20, 38, NULL, 11, NULL, NULL, NULL, `Purchase Cash` `Pay`, `Dr`., 2250, 0, `2022-09-28` `08:13:33`, 23, `2022-09-28` `19:13:33`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: ledger_vat
#

DROP TABLE IF EXISTS `ledger_vat`;

CREATE TABLE `ledger_vat` (
  `ledg_vat_id` int(11) NOT NULL AUTO_INCREMENT,
  `vat_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `sch_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `particulars` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` double NOT NULL,
  `rest_balance` double NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledg_vat_id`),
  KEY `lc_id` (`invoice_id`),
  KEY `sch_id` (`sch_id`),
  KEY `trans_id` (`trans_id`),
  KEY `vat_id` (`vat_id`),
  CONSTRAINT `ledger_vat_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_vat_ibfk_2` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `ledger_vat_ibfk_3` FOREIGN KEY (`trans_id`) REFERENCES `transaction` (`trans_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `ledger_vat` (`ledg_vat_id`, `vat_id`, `invoice_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 1, 23, NULL, `Sale Vat` `Earn`, `Cr`., `8`.`23`, `-8`.`23`, `2022-09-26` `11:57:09`, 0, `2022-09-27` `10:57:09`, NULL, NULL, NULL);
INSERT INTO `ledger_vat` (`ledg_vat_id`, `vat_id`, `invoice_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 23, NULL, 23, 145, `erreyre`, `Dr`., 8, `-0`.`23`, `2022-09-27` `12:07:46`, 26, `2022-09-27` `11:07:46`, NULL, NULL, NULL);
INSERT INTO `ledger_vat` (`ledg_vat_id`, `vat_id`, `invoice_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 22, 3, 22, NULL, `Sale Vat` `Earn`, `Cr`., 152, `-152`, `2022-09-27` `09:03:33`, 0, `2022-09-27` `20:03:33`, NULL, NULL, NULL);
INSERT INTO `ledger_vat` (`ledg_vat_id`, `vat_id`, `invoice_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 20, 4, 20, NULL, `Sale Vat` `Earn`, `Cr`., `16`.`46`, `-16`.`46`, `2022-09-27` `09:10:14`, 0, `2022-09-27` `20:10:14`, NULL, NULL, NULL);
INSERT INTO `ledger_vat` (`ledg_vat_id`, `vat_id`, `invoice_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 20, 5, 20, NULL, `Sale Vat` `Earn`, `Cr`., `8`.`23`, `-24`.`69`, `2022-09-28` `08:33:29`, 0, `2022-09-28` `19:33:29`, NULL, NULL, NULL);
INSERT INTO `ledger_vat` (`ledg_vat_id`, `vat_id`, `invoice_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 22, NULL, 22, 154, `Vat`, `Dr`., 152, 0, `2022-09-28` `08:41:47`, 25, `2022-09-28` `19:41:47`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: license
#

DROP TABLE IF EXISTS `license`;

CREATE TABLE `license` (
  `lic_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `lic_key` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`lic_id`),
  UNIQUE KEY `sch_id_2` (`sch_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `license_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `license` (`lic_id`, `sch_id`, `lic_key`, `start_date`, `end_date`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (17, 20, `6331a7d85cc63`, `2022-09-25`, `2026-10-26`, 1, `2022-09-26` `19:23:36`, 0, `2022-09-26` `19:23:36`, NULL, NULL, NULL);
INSERT INTO `license` (`lic_id`, `sch_id`, `lic_key`, `start_date`, `end_date`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (18, 21, `6331a872030ca`, `2022-09-26`, `2026-12-26`, 1, `2022-09-26` `19:26:10`, 0, `2022-09-26` `19:26:10`, NULL, NULL, NULL);
INSERT INTO `license` (`lic_id`, `sch_id`, `lic_key`, `start_date`, `end_date`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (19, 22, `6331adec56465`, `2022-09-26`, `2026-12-26`, 1, `2022-09-26` `19:49:32`, 0, `2022-09-26` `19:49:32`, NULL, NULL, NULL);
INSERT INTO `license` (`lic_id`, `sch_id`, `lic_key`, `start_date`, `end_date`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (20, 23, `633274edbd7ce`, `2022-09-27`, `2026-09-27`, 1, `2022-09-27` `09:58:37`, 0, `2022-09-27` `09:58:37`, NULL, NULL, NULL);
INSERT INTO `license` (`lic_id`, `sch_id`, `lic_key`, `start_date`, `end_date`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (21, 24, `6337d66e8d13c`, `2022-10-01`, `2023-10-01`, 1, `2022-10-01` `11:55:58`, 0, `2022-10-01` `11:55:58`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: loan_provider
#

DROP TABLE IF EXISTS `loan_provider`;

CREATE TABLE `loan_provider` (
  `loan_pro_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` int(11) DEFAULT NULL,
  `address` text,
  `balance` double NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`loan_pro_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `loan_provider_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

INSERT INTO `loan_provider` (`loan_pro_id`, `sch_id`, `name`, `phone`, `address`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (48, 20, `Sumon`, 1456321458, `Mirpur,` `Dhaka`, `-100000`, `2022-09-26` `08:46:03`, 23, `2022-09-29` `19:31:37`, 23, NULL, NULL);
INSERT INTO `loan_provider` (`loan_pro_id`, `sch_id`, `name`, `phone`, `address`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (50, 23, `example`, 1924331313, NULL, `-20000`, `2022-09-27` `09:59:35`, 23, `2022-09-27` `11:04:38`, 26, NULL, NULL);
INSERT INTO `loan_provider` (`loan_pro_id`, `sch_id`, `name`, `phone`, `address`, `balance`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (51, 22, `Murad`, 1714070771, `Dhaka`, `-500000`, `2022-09-27` `08:44:21`, 25, `2022-09-27` `19:56:52`, 25, NULL, NULL);


#
# TABLE STRUCTURE FOR: money_receipt
#

DROP TABLE IF EXISTS `money_receipt`;

CREATE TABLE `money_receipt` (
  `money_receipt_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `name` varchar(155) DEFAULT NULL,
  `amount` double unsigned NOT NULL,
  `date` datetime NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`money_receipt_id`),
  KEY `sch_id` (`sch_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `money_receipt_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `money_receipt_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: payment_type
#

DROP TABLE IF EXISTS `payment_type`;

CREATE TABLE `payment_type` (
  `pymnt_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `type_name` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`pymnt_type_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `payment_type_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: product_category
#

DROP TABLE IF EXISTS `product_category`;

CREATE TABLE `product_category` (
  `prod_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `parent_pro_cat` int(11) NOT NULL,
  `product_category` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`prod_cat_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `product_category_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;

INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (60, 20, 0, `Men`, 1, `2022-09-26` `08:58:56`, 23, `2022-09-26` `19:58:56`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (61, 20, 60, `T-Shirt`, 1, `2022-09-26` `08:59:35`, 23, `2022-09-26` `19:59:35`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (62, 20, 0, `Women`, 1, `2022-09-26` `08:59:49`, 23, `2022-09-26` `19:59:49`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (63, 20, 62, `Dress`, 1, `2022-09-26` `09:00:21`, 23, `2022-09-26` `20:00:21`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (66, 23, 0, `Men`, 1, `2022-09-26` `11:37:19`, 26, `2022-09-27` `10:37:19`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (67, 23, 66, `T-Shart`, 1, `2022-09-26` `11:37:30`, 26, `2022-09-27` `10:37:30`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (68, 22, 0, `Bag`, 1, `2022-09-27` `08:46:50`, 25, `2022-09-27` `19:46:50`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (69, 22, 68, `Men` `bag`, 1, `2022-09-27` `08:47:03`, 25, `2022-09-27` `19:47:03`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (70, 22, 68, `Women` `bag`, 1, `2022-09-27` `08:47:09`, 25, `2022-09-27` `19:47:09`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (85, 20, 0, `hat`, 1, `2022-09-28` `08:07:41`, 23, `2022-09-28` `19:07:41`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (86, 20, 85, `Men`, 1, `2022-09-28` `08:07:47`, 23, `2022-09-28` `19:07:47`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (87, 20, 62, `hat`, 1, `2022-09-28` `08:07:53`, 23, `2022-09-28` `19:08:43`, 23, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (88, 20, 85, `Men`, 1, `2022-09-28` `08:09:47`, 23, `2022-09-28` `19:09:47`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (89, 20, 60, `hat`, 1, `2022-09-28` `08:10:29`, 23, `2022-09-28` `19:10:29`, NULL, NULL, NULL);
INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (90, 20, 62, `hat`, 1, `2022-09-28` `08:10:35`, 23, `2022-09-28` `19:10:35`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `prod_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `name` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) unsigned NOT NULL,
  `unit` int(11) NOT NULL,
  `purchase_price` double NOT NULL,
  `selling_price` double NOT NULL,
  `purchase_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Last purchase price will be added here.',
  `supplier_id` int(11) NOT NULL,
  `size` int(11) DEFAULT NULL,
  `serial_number` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `picture` varchar(155) DEFAULT NULL,
  `warranty` varchar(55) DEFAULT NULL,
  `barcode` varchar(55) DEFAULT NULL,
  `prod_cat_id` int(11) DEFAULT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`prod_id`),
  KEY `sch_id` (`sch_id`),
  KEY `store_id` (`store_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `prod_cat_id` (`prod_cat_id`),
  KEY `brand_id` (`brand_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`store_id`) REFERENCES `stores` (`store_id`) ON UPDATE CASCADE,
  CONSTRAINT `products_ibfk_4` FOREIGN KEY (`prod_cat_id`) REFERENCES `product_category` (`prod_cat_id`) ON UPDATE CASCADE,
  CONSTRAINT `products_ibfk_5` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`),
  CONSTRAINT `products_ibfk_6` FOREIGN KEY (`brand_id`) REFERENCES `brand` (`brand_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `products` (`prod_id`, `sch_id`, `store_id`, `name`, `quantity`, `unit`, `purchase_price`, `selling_price`, `purchase_date`, `supplier_id`, `size`, `serial_number`, `brand_id`, `picture`, `warranty`, `barcode`, `prod_cat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 26, `Floral Alphabet Letters White Color T-Shirt for` `Men`, 47, 1, 60, 100, `2022-09-27` `10:47:55`, 40, NULL, NULL, NULL, `product_1664792043_80a4e738d953a42b2767`.`jpg`, NULL, NULL, 67, `2022-09-26` `11:47:55`, 26, `2022-10-03` `16:14:03`, 26, NULL, NULL);
INSERT INTO `products` (`prod_id`, `sch_id`, `store_id`, `name`, `quantity`, `unit`, `purchase_price`, `selling_price`, `purchase_date`, `supplier_id`, `size`, `serial_number`, `brand_id`, `picture`, `warranty`, `barcode`, `prod_cat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 23, 26, `Stylish Alphabet A To Z T-shirt For` `Unisex`, 49, 1, 60, 120, `2022-09-27` `10:47:55`, 40, NULL, NULL, NULL, `product_1664792055_c80e8c735a404282bfbd`.`jpg`, NULL, NULL, 67, `2022-09-26` `11:47:55`, 26, `2022-10-03` `16:14:15`, 26, NULL, NULL);
INSERT INTO `products` (`prod_id`, `sch_id`, `store_id`, `name`, `quantity`, `unit`, `purchase_price`, `selling_price`, `purchase_date`, `supplier_id`, `size`, `serial_number`, `brand_id`, `picture`, `warranty`, `barcode`, `prod_cat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 23, 26, `An Ideal Tree Decorative Short Sleeve` `Tshirt`, 48, 1, 50, 100, `2022-09-27` `10:47:55`, 40, NULL, NULL, NULL, `product_1664792063_83fb4c761d9da6aed25f`.`jpg`, NULL, NULL, 67, `2022-09-26` `11:47:55`, 26, `2022-10-03` `16:14:23`, 26, NULL, NULL);
INSERT INTO `products` (`prod_id`, `sch_id`, `store_id`, `name`, `quantity`, `unit`, `purchase_price`, `selling_price`, `purchase_date`, `supplier_id`, `size`, `serial_number`, `brand_id`, `picture`, `warranty`, `barcode`, `prod_cat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 20, 23, `panda` `t-shirt`, 8, 1, 200, 280, `2022-09-27` `19:25:56`, 38, NULL, NULL, NULL, NULL, NULL, NULL, 61, `2022-09-27` `08:25:56`, 23, `2022-09-27` `20:10:14`, 23, NULL, NULL);
INSERT INTO `products` (`prod_id`, `sch_id`, `store_id`, `name`, `quantity`, `unit`, `purchase_price`, `selling_price`, `purchase_date`, `supplier_id`, `size`, `serial_number`, `brand_id`, `picture`, `warranty`, `barcode`, `prod_cat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 20, 23, `Kiron mala` `dress`, 10, 1, 300, 450, `2022-09-27` `19:28:19`, 38, NULL, NULL, NULL, NULL, NULL, NULL, 63, `2022-09-27` `08:28:19`, 23, `2022-09-27` `19:28:19`, NULL, NULL, NULL);
INSERT INTO `products` (`prod_id`, `sch_id`, `store_id`, `name`, `quantity`, `unit`, `purchase_price`, `selling_price`, `purchase_date`, `supplier_id`, `size`, `serial_number`, `brand_id`, `picture`, `warranty`, `barcode`, `prod_cat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 22, 25, `Keepall`, 48, 1, 2500, 4000, `2022-09-27` `20:00:02`, 41, NULL, NULL, NULL, NULL, NULL, NULL, 69, `2022-09-27` `09:00:02`, 25, `2022-09-27` `20:03:34`, 25, NULL, NULL);
INSERT INTO `products` (`prod_id`, `sch_id`, `store_id`, `name`, `quantity`, `unit`, `purchase_price`, `selling_price`, `purchase_date`, `supplier_id`, `size`, `serial_number`, `brand_id`, `picture`, `warranty`, `barcode`, `prod_cat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (9, 20, 23, `xiaomi` `hat`, 14, 1, 150, 280, `2022-09-28` `19:13:33`, 38, NULL, NULL, NULL, NULL, NULL, NULL, 89, `2022-09-28` `08:13:33`, 23, `2022-09-28` `19:33:29`, 23, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchase
#

DROP TABLE IF EXISTS `purchase`;

CREATE TABLE `purchase` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `nagad_paid` double DEFAULT NULL,
  `bank_paid` double DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `due` double DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`purchase_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `purchase_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `purchase` (`purchase_id`, `sch_id`, `supplier_id`, `amount`, `nagad_paid`, `bank_paid`, `bank_id`, `due`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 40, 8500, 8000, 0, 0, 500, `2022-09-26` `11:44:05`, 26, `2022-09-27` `10:47:55`, 26, NULL, NULL);
INSERT INTO `purchase` (`purchase_id`, `sch_id`, `supplier_id`, `amount`, `nagad_paid`, `bank_paid`, `bank_id`, `due`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 20, 38, 2000, 2000, 0, 0, 0, `2022-09-27` `08:22:57`, 23, `2022-09-27` `19:25:56`, 23, NULL, NULL);
INSERT INTO `purchase` (`purchase_id`, `sch_id`, `supplier_id`, `amount`, `nagad_paid`, `bank_paid`, `bank_id`, `due`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 20, 38, 3000, 3000, 0, 0, 0, `2022-09-27` `08:26:34`, 23, `2022-09-27` `19:28:19`, 23, NULL, NULL);
INSERT INTO `purchase` (`purchase_id`, `sch_id`, `supplier_id`, `amount`, `nagad_paid`, `bank_paid`, `bank_id`, `due`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 22, 41, 125000, 125000, 0, 0, 0, `2022-09-27` `08:58:11`, 25, `2022-09-27` `20:00:02`, 25, NULL, NULL);
INSERT INTO `purchase` (`purchase_id`, `sch_id`, `supplier_id`, `amount`, `nagad_paid`, `bank_paid`, `bank_id`, `due`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (11, 20, 38, 2250, 2250, 0, 0, 0, `2022-09-28` `08:10:45`, 23, `2022-09-28` `19:13:33`, 23, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchase_item
#

DROP TABLE IF EXISTS `purchase_item`;

CREATE TABLE `purchase_item` (
  `purchase_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `purchase_price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` double NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`purchase_item_id`),
  KEY `supplier_id` (`prod_id`),
  KEY `purchase_item_id` (`purchase_item_id`),
  KEY `purchase_id` (`purchase_id`),
  CONSTRAINT `purchase_item_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `purchase` (`purchase_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_item` (`purchase_item_id`, `purchase_id`, `prod_id`, `purchase_price`, `quantity`, `total_price`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 1, 1, 60, 50, 3000, `2022-09-26` `11:47:55`, 26, `2022-09-27` `10:47:55`, NULL, NULL, NULL);
INSERT INTO `purchase_item` (`purchase_item_id`, `purchase_id`, `prod_id`, `purchase_price`, `quantity`, `total_price`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 1, 2, 60, 50, 3000, `2022-09-26` `11:47:55`, 26, `2022-09-27` `10:47:55`, NULL, NULL, NULL);
INSERT INTO `purchase_item` (`purchase_item_id`, `purchase_id`, `prod_id`, `purchase_price`, `quantity`, `total_price`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 1, 3, 50, 50, 2500, `2022-09-26` `11:47:55`, 26, `2022-09-27` `10:47:55`, NULL, NULL, NULL);
INSERT INTO `purchase_item` (`purchase_item_id`, `purchase_id`, `prod_id`, `purchase_price`, `quantity`, `total_price`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 2, 4, 200, 10, 2000, `2022-09-27` `08:25:56`, 23, `2022-09-27` `19:25:56`, NULL, NULL, NULL);
INSERT INTO `purchase_item` (`purchase_item_id`, `purchase_id`, `prod_id`, `purchase_price`, `quantity`, `total_price`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 3, 5, 300, 10, 3000, `2022-09-27` `08:28:19`, 23, `2022-09-27` `19:28:19`, NULL, NULL, NULL);
INSERT INTO `purchase_item` (`purchase_item_id`, `purchase_id`, `prod_id`, `purchase_price`, `quantity`, `total_price`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (6, 4, 6, 2500, 50, 125000, `2022-09-27` `09:00:02`, 25, `2022-09-27` `20:00:02`, NULL, NULL, NULL);
INSERT INTO `purchase_item` (`purchase_item_id`, `purchase_id`, `prod_id`, `purchase_price`, `quantity`, `total_price`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (9, 11, 9, 150, 15, 2250, `2022-09-28` `08:13:33`, 23, `2022-09-28` `19:13:33`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: return_purchase
#

DROP TABLE IF EXISTS `return_purchase`;

CREATE TABLE `return_purchase` (
  `rtn_purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `pymnt_type_id` int(11) DEFAULT NULL,
  `customer_name` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` double unsigned NOT NULL,
  `rtn_profit` double NOT NULL COMMENT 'profit on the sale',
  `nagad_paid` double unsigned DEFAULT NULL,
  `bank_paid` double unsigned DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `creation_timestamp` int(11) DEFAULT NULL,
  `payment_timestamp` longtext COLLATE utf8_unicode_ci,
  `payment_method` longtext COLLATE utf8_unicode_ci,
  `payment_details` longtext COLLATE utf8_unicode_ci,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `year` longtext COLLATE utf8_unicode_ci,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`rtn_purchase_id`),
  KEY `sch_id` (`sch_id`),
  KEY `student_id` (`supplier_id`),
  KEY `pymnt_type_id` (`pymnt_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: return_purchase_item
#

DROP TABLE IF EXISTS `return_purchase_item`;

CREATE TABLE `return_purchase_item` (
  `rtn_purchase_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `rtn_purchase_id` int(11) NOT NULL,
  `sch_id` int(11) NOT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `title` varchar(155) DEFAULT NULL COMMENT 'It will be used, if prod_id is not inserted into the table.',
  `price` double unsigned NOT NULL,
  `quantity` int(11) unsigned NOT NULL,
  `total_price` double unsigned NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) unsigned DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`rtn_purchase_item_id`),
  KEY `invoice_id` (`rtn_purchase_id`),
  KEY `inv_exist_item_id` (`prod_id`),
  KEY `sch_id` (`sch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: return_sale
#

DROP TABLE IF EXISTS `return_sale`;

CREATE TABLE `return_sale` (
  `rtn_sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `pymnt_type_id` int(11) DEFAULT NULL,
  `customer_name` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` double NOT NULL,
  `rtn_profit` double NOT NULL COMMENT 'profit on the sale',
  `nagad_paid` double unsigned DEFAULT NULL,
  `bank_paid` double unsigned DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `creation_timestamp` int(11) DEFAULT NULL,
  `payment_timestamp` longtext COLLATE utf8_unicode_ci,
  `payment_method` longtext COLLATE utf8_unicode_ci,
  `payment_details` longtext COLLATE utf8_unicode_ci,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `year` longtext COLLATE utf8_unicode_ci,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`rtn_sale_id`),
  KEY `sch_id` (`sch_id`),
  KEY `student_id` (`customer_id`),
  KEY `pymnt_type_id` (`pymnt_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: return_sale_item
#

DROP TABLE IF EXISTS `return_sale_item`;

CREATE TABLE `return_sale_item` (
  `rtn_sale_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `rtn_sale_id` int(11) NOT NULL,
  `sch_id` int(11) NOT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `title` varchar(155) DEFAULT NULL COMMENT 'It will be used, if prod_id is not inserted into the table.',
  `price` double unsigned NOT NULL,
  `quantity` int(11) unsigned NOT NULL,
  `total_price` double unsigned NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) unsigned DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`rtn_sale_item_id`),
  KEY `invoice_id` (`rtn_sale_id`),
  KEY `inv_exist_item_id` (`prod_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `return_sale_item_ibfk_1` FOREIGN KEY (`rtn_sale_id`) REFERENCES `return_sale` (`rtn_sale_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `role` varchar(30) NOT NULL,
  `permission` text NOT NULL,
  `is_default` enum('1','0') NOT NULL DEFAULT '0',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedby` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`role_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`role_id`, `sch_id`, `role`, `permission`, `is_default`, `createdBy`, `createdDtm`, `updatedby`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (22, 20, `Admin`, `{"Dashboard":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Pages":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_item":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Product_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_deposit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Settings":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_withdraw":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Warranty_manage":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Role":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Money_receipt":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Loan_provider":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_nagodan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_loan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"User":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stores":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Invoice":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Expense_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Balance_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc_installment":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customer_type":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Products":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Transaction":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Chaque":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stock_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Daily_book":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Brand":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_sale":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Vat_register":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_vat":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Acquisition_due":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Owe_amount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Trial_balance":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_profit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_stock":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_expense":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"HeadToheadTransfer":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_other_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_discount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"}}`, 1, 1, `2022-09-26` `08:23:15`, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `roles` (`role_id`, `sch_id`, `role`, `permission`, `is_default`, `createdBy`, `createdDtm`, `updatedby`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (23, 21, `Admin`, `{"Dashboard":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Pages":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_item":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Product_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_deposit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Settings":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_withdraw":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Warranty_manage":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Role":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Money_receipt":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Loan_provider":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_nagodan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_loan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"User":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stores":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Invoice":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Expense_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Balance_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc_installment":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customer_type":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Products":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Transaction":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Chaque":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stock_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Daily_book":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Brand":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_sale":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Vat_register":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_vat":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Acquisition_due":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Owe_amount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Trial_balance":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_profit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_stock":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_expense":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"HeadToheadTransfer":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_other_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_discount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"}}`, 1, 1, `2022-09-26` `08:25:24`, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `roles` (`role_id`, `sch_id`, `role`, `permission`, `is_default`, `createdBy`, `createdDtm`, `updatedby`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (24, 22, `Admin`, `{"Dashboard":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Pages":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_item":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Product_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_deposit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Settings":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_withdraw":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Warranty_manage":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Role":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Money_receipt":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Loan_provider":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_nagodan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_loan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"User":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stores":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Invoice":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Expense_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Balance_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc_installment":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customer_type":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Products":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Transaction":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Chaque":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stock_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Daily_book":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Brand":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_sale":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Vat_register":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_vat":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Acquisition_due":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Owe_amount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Trial_balance":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_profit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_stock":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_expense":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"HeadToheadTransfer":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_other_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_discount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"}}`, 1, 1, `2022-09-26` `08:49:10`, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `roles` (`role_id`, `sch_id`, `role`, `permission`, `is_default`, `createdBy`, `createdDtm`, `updatedby`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (25, 23, `Admin`, `{"Dashboard":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Pages":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_item":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Product_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_deposit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Settings":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_withdraw":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Warranty_manage":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Role":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Money_receipt":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Loan_provider":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_nagodan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_loan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"User":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stores":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Invoice":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Expense_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Balance_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc_installment":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customer_type":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Products":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Transaction":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Chaque":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stock_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Daily_book":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Brand":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_sale":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Vat_register":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_vat":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Acquisition_due":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Owe_amount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Trial_balance":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_profit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_stock":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_expense":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"HeadToheadTransfer":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_other_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_discount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"}}`, 1, 1, `2022-09-26` `10:58:18`, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `roles` (`role_id`, `sch_id`, `role`, `permission`, `is_default`, `createdBy`, `createdDtm`, `updatedby`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (26, 23, `Maneger`, `{"Dashboard":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Pages":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Bank":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Customers":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"0"},"Purchase_item":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Product_category":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Bank_deposit":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Settings":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"0"},"Bank_withdraw":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Warranty_manage":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Suppliers":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Sales":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0","discount":"0","warranty":"0"},"Role":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Money_receipt":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Loan_provider":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Ledger_suppliers":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Ledger_nagodan":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Ledger_loan":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"User":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Stores":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Ledger_lc":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Ledger_bank":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Invoice":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0","discount":"0","warranty":"0"},"Expense_category":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Balance_report":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Ledger":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Lc_installment":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Lc":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Customer_type":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Products":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Transaction":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Chaque":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Stock_report":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Sales_report":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Purchase_report":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Daily_book":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Brand":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Employee":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Ledger_employee":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Return_sale":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Return_purchase":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Vat_register":{"mod_access":"0","create":"0","read":"0","update":"0","delete":"0"},"Ledger_vat":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Acquisition_due":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Owe_amount":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Trial_balance":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Ledger_purchase":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Ledger_sales":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Capital":{"mod_access":"1","create":"1","read":"0","update":"0","delete":"0"},"Ledger_capital":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Ledger_profit":{"mod_access":"1","create":"0","read":"0","update":"0","delete":"0"},"Ledger_stock":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Ledger_expense":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"HeadToheadTransfer":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Ledger_other_sales":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"},"Ledger_discount":{"mod_access":"1","create":"1","read":"1","update":"0","delete":"0"}}`, 0, 26, `2022-09-27` `12:49:45`, 26, `2022-09-27` `11:50:35`, NULL, NULL);
INSERT INTO `roles` (`role_id`, `sch_id`, `role`, `permission`, `is_default`, `createdBy`, `createdDtm`, `updatedby`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (27, 24, `Admin`, `{"Dashboard":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Pages":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_item":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Product_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_deposit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Settings":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Bank_withdraw":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Warranty_manage":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Role":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Money_receipt":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Loan_provider":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_suppliers":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_nagodan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_loan":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"User":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stores":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_bank":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Invoice":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1","discount":"1","warranty":"1"},"Expense_category":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Balance_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc_installment":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Lc":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Customer_type":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Products":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Transaction":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Chaque":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Stock_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Sales_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Purchase_report":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Daily_book":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Brand":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_employee":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_sale":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Return_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Vat_register":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_vat":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Acquisition_due":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Owe_amount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_purchase":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Trial_balance":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_capital":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_profit":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_stock":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_expense":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"HeadToheadTransfer":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_other_sales":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"},"Ledger_discount":{"mod_access":"1","create":"1","read":"1","update":"1","delete":"1"}}`, 1, 1, `2022-10-01` `12:22:37`, NULL, `2022-10-01` `11:22:37`, NULL, NULL);


#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS `sales`;

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`sales_id`),
  KEY `sch_id` (`sch_id`),
  KEY `prod_id` (`invoice_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `sales` (`sales_id`, `sch_id`, `invoice_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (1, 23, 1, `2022-09-26` `11:57:09`, 0, `2022-09-27` `10:57:09`, NULL, NULL, NULL);
INSERT INTO `sales` (`sales_id`, `sch_id`, `invoice_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (2, 23, 2, `2022-09-27` `12:05:54`, 0, `2022-09-27` `11:05:54`, NULL, NULL, NULL);
INSERT INTO `sales` (`sales_id`, `sch_id`, `invoice_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (3, 22, 3, `2022-09-27` `09:03:34`, 0, `2022-09-27` `20:03:34`, NULL, NULL, NULL);
INSERT INTO `sales` (`sales_id`, `sch_id`, `invoice_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (4, 20, 4, `2022-09-27` `09:10:14`, 0, `2022-09-27` `20:10:14`, NULL, NULL, NULL);
INSERT INTO `sales` (`sales_id`, `sch_id`, `invoice_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (5, 20, 5, `2022-09-28` `08:33:29`, 0, `2022-09-28` `19:33:29`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: shops
#

DROP TABLE IF EXISTS `shops`;

CREATE TABLE `shops` (
  `sch_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `cash` double unsigned NOT NULL COMMENT 'This is the nagad cash of the shop owner.',
  `capital` double DEFAULT NULL,
  `profit` double DEFAULT NULL,
  `stockAmount` double DEFAULT NULL,
  `expense` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `purchase_balance` double NOT NULL,
  `sale_balance` double NOT NULL,
  `address` text,
  `mobile` int(11) DEFAULT NULL,
  `comment` text,
  `logo` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `opening_status` enum('0','1') NOT NULL DEFAULT '0',
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`sch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO `shops` (`sch_id`, `name`, `email`, `cash`, `capital`, `profit`, `stockAmount`, `expense`, `discount`, `purchase_balance`, `sale_balance`, `address`, `mobile`, `comment`, `logo`, `image`, `createdDtm`, `updatedBy`, `updatedDtm`, `status`, `opening_status`, `deleted`, `deletedRole`) VALUES (20, `Munna` `Store`, `munna123@gmail`.`com`, `88497`.`63`, `-20000`, `-273`.`2`, 6700, 100, `-7`.`89`, 7250, `-823`.`89`, `Noapara, Abhaynagar,` `Jashor`, 1947625978, ...............................`!`, NULL, NULL, `2022-09-26` `19:23:15`, 23, `2022-10-02` `08:51:28`, 1, 0, NULL, NULL);
INSERT INTO `shops` (`sch_id`, `name`, `email`, `cash`, `capital`, `profit`, `stockAmount`, `expense`, `discount`, `purchase_balance`, `sale_balance`, `address`, `mobile`, `comment`, `logo`, `image`, `createdDtm`, `updatedBy`, `updatedDtm`, `status`, `opening_status`, `deleted`, `deletedRole`) VALUES (21, `Hasib` `Store`, `abhasibul@gmail`.`com`, 50000, `-50000`, 0, 0, 0, `-790`.`82`, 0, 0, NULL, NULL, NULL, NULL, NULL, `2022-09-26` `19:25:24`, 24, `2022-10-03` `05:32:40`, 1, 1, NULL, NULL);
INSERT INTO `shops` (`sch_id`, `name`, `email`, `cash`, `capital`, `profit`, `stockAmount`, `expense`, `discount`, `purchase_balance`, `sale_balance`, `address`, `mobile`, `comment`, `logo`, `image`, `createdDtm`, `updatedBy`, `updatedDtm`, `status`, `opening_status`, `deleted`, `deletedRole`) VALUES (22, `Sumon` `Shop`, `sumon1@gmail`.`com`, 1222600, `-1002000`, `-22600`, 120000, 40000, 248, 125000, `-7600`, NULL, NULL, NULL, NULL, NULL, `2022-09-26` `19:49:10`, 25, `2022-09-28` `19:41:47`, 1, 0, NULL, NULL);
INSERT INTO `shops` (`sch_id`, `name`, `email`, `cash`, `capital`, `profit`, `stockAmount`, `expense`, `discount`, `purchase_balance`, `sale_balance`, `address`, `mobile`, `comment`, `logo`, `image`, `createdDtm`, `updatedBy`, `updatedDtm`, `status`, `opening_status`, `deleted`, `deletedRole`) VALUES (23, `Murad` `shop`, `murad@gmail`.`com`, 42022, `-50000`, `-321`.`6`, 8160, 20, `0`.`17000000000002`, 8500, `-611`.`83`, NULL, NULL, NULL, `profile_1664792077_18f89437a9f354e29564`.`png`, `pro_1664792093_47f73ab35870f20284db`.`jpg`, `2022-09-27` `09:58:18`, 26, `2022-10-03` `16:14:53`, 1, 0, NULL, NULL);
INSERT INTO `shops` (`sch_id`, `name`, `email`, `cash`, `capital`, `profit`, `stockAmount`, `expense`, `discount`, `purchase_balance`, `sale_balance`, `address`, `mobile`, `comment`, `logo`, `image`, `createdDtm`, `updatedBy`, `updatedDtm`, `status`, `opening_status`, `deleted`, `deletedRole`) VALUES (24, Imran's Shopds, `imran@dnationsoft`.`com`, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, , 1924329315, , NULL, NULL, `2022-10-01` `11:22:37`, 29, `2022-10-01` `01:22:43`, 1, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: stores
#

DROP TABLE IF EXISTS `stores`;

CREATE TABLE `stores` (
  `store_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text NOT NULL,
  `is_default` enum('1','0') NOT NULL DEFAULT '0',
  `createdDtm` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`store_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `stores_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `stores` (`store_id`, `sch_id`, `name`, `description`, `is_default`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (23, 20, `Default`, `Default` `Store`, 1, `2022-09-26` `08:23:15`, NULL, `2022-09-26` `19:23:15`, NULL, NULL);
INSERT INTO `stores` (`store_id`, `sch_id`, `name`, `description`, `is_default`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (24, 21, `Default`, `Default` `Store`, 1, `2022-09-26` `08:25:24`, NULL, `2022-09-26` `19:25:24`, NULL, NULL);
INSERT INTO `stores` (`store_id`, `sch_id`, `name`, `description`, `is_default`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (25, 22, `Default`, `Default` `Store`, 1, `2022-09-26` `08:49:10`, NULL, `2022-09-26` `19:49:10`, NULL, NULL);
INSERT INTO `stores` (`store_id`, `sch_id`, `name`, `description`, `is_default`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (26, 23, `Default`, `Default` `Store`, 1, `2022-09-26` `10:58:18`, NULL, `2022-09-27` `09:58:18`, NULL, NULL);
INSERT INTO `stores` (`store_id`, `sch_id`, `name`, `description`, `is_default`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (27, 24, `Default`, `Default` `Store`, 1, `2022-10-01` `12:22:37`, NULL, `2022-10-01` `11:22:37`, NULL, NULL);


#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS `suppliers`;

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `balance` double NOT NULL,
  `address` text,
  `phone` int(11) DEFAULT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `suppliers_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

INSERT INTO `suppliers` (`supplier_id`, `sch_id`, `name`, `balance`, `address`, `phone`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (38, 20, `Sabbir`, 0, `Khulna`, 1365784574, `2022-09-26` `08:51:57`, 23, `2022-09-28` `19:13:33`, 23, NULL, NULL);
INSERT INTO `suppliers` (`supplier_id`, `sch_id`, `name`, `balance`, `address`, `phone`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (40, 23, `example`, 0, NULL, 1924331313, `2022-09-27` `09:59:41`, 23, `2022-09-27` `11:04:19`, 26, NULL, NULL);
INSERT INTO `suppliers` (`supplier_id`, `sch_id`, `name`, `balance`, `address`, `phone`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (41, 22, `Imran`, 0, `Khula`, 1929649448, `2022-09-27` `08:45:24`, 25, `2022-09-27` `20:00:02`, 25, NULL, NULL);
INSERT INTO `suppliers` (`supplier_id`, `sch_id`, `name`, `balance`, `address`, `phone`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (42, 22, `Rahim`, 0, `Dhaka`, 1744445444, `2022-09-27` `08:45:40`, 25, `2022-09-27` `19:45:40`, NULL, NULL, NULL);
INSERT INTO `suppliers` (`supplier_id`, `sch_id`, `name`, `balance`, `address`, `phone`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (43, 21, `Samsung` `Mobile`, 0, `Dhaka`, 1140100, `2022-10-03` `06:34:07`, 24, `2022-10-03` `18:34:07`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: transaction
#

DROP TABLE IF EXISTS `transaction`;

CREATE TABLE `transaction` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `title` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL,
  `amount` double unsigned NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `loan_pro_id` int(11) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `lc_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `vat_id` int(11) DEFAULT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`trans_id`),
  KEY `sch_id` (`sch_id`),
  KEY `customer_id` (`customer_id`),
  KEY `loan_pro_id` (`loan_pro_id`),
  KEY `bank_id` (`bank_id`),
  KEY `lc_id` (`lc_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `vat_id` (`vat_id`),
  CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON UPDATE CASCADE,
  CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`loan_pro_id`) REFERENCES `loan_provider` (`loan_pro_id`) ON UPDATE CASCADE,
  CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`bank_id`) ON UPDATE CASCADE,
  CONSTRAINT `transaction_ibfk_4` FOREIGN KEY (`lc_id`) REFERENCES `lc` (`lc_id`) ON UPDATE CASCADE,
  CONSTRAINT `transaction_ibfk_5` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`) ON UPDATE CASCADE,
  CONSTRAINT `transaction_ibfk_6` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE,
  CONSTRAINT `transaction_ibfk_7` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON UPDATE CASCADE,
  CONSTRAINT `transaction_ibfk_8` FOREIGN KEY (`vat_id`) REFERENCES `vat_register` (`vat_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=latin1;

INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (139, 20, `Loan`, NULL, `Dr`., 100000, NULL, 48, NULL, NULL, NULL, NULL, NULL, `2022-09-26` `09:03:02`, 23, `2022-09-26` `20:03:02`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (140, 23, `pay`, NULL, `Dr`., 300, 92, NULL, NULL, NULL, NULL, NULL, NULL, `2022-09-27` `12:03:43`, 26, `2022-09-27` `11:03:43`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (141, 23, `pay`, NULL, `Cr`., 500, NULL, NULL, NULL, NULL, 40, NULL, NULL, `2022-09-27` `12:04:19`, 26, `2022-09-27` `11:04:19`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (142, 23, `lone`, NULL, `Dr`., 20000, NULL, 50, NULL, NULL, NULL, NULL, NULL, `2022-09-27` `12:04:38`, 26, `2022-09-27` `11:04:38`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (143, 23, `sfs`, NULL, `Cr`., 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `2022-09-27` `12:06:59`, 26, `2022-09-27` `11:06:59`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (144, 23, `gtdg`, NULL, `Dr`., 50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `2022-09-27` `12:07:22`, 26, `2022-09-27` `11:07:22`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (145, 23, `erreyre`, NULL, `Dr`., 8, NULL, NULL, NULL, NULL, NULL, NULL, 23, `2022-09-27` `12:07:46`, 26, `2022-09-27` `11:07:46`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (146, 23, `Withdraw`, NULL, `Cr`., 10000, NULL, NULL, 34, NULL, NULL, NULL, NULL, `2022-09-27` `12:08:30`, 26, `2022-09-27` `11:08:30`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (148, 22, `Loan`, NULL, `Dr`., 500000, NULL, 51, NULL, NULL, NULL, NULL, NULL, `2022-09-27` `08:56:52`, 25, `2022-09-27` `19:56:52`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (150, 22, `Decoration`, NULL, `Cr`., 40000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `2022-09-28` `08:34:32`, 25, `2022-09-28` `19:34:32`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (151, 22, `iudfugigju`, NULL, `Dr`., 20000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `2022-09-28` `08:35:59`, 25, `2022-09-28` `19:35:59`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (152, 22, `Salary`, NULL, `Cr`., 5000, NULL, NULL, NULL, NULL, NULL, 3, NULL, `2022-09-28` `08:37:43`, 25, `2022-09-28` `19:37:43`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (153, 20, `ioh`, NULL, `Cr`., 100, NULL, NULL, NULL, NULL, NULL, NULL, NULL, `2022-09-28` `08:41:43`, 23, `2022-09-28` `19:41:43`, NULL, NULL, NULL);
INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `createdDtm`, `createdBy`, `updateDtm`, `updatedBy`, `deleted`, `deletedRole`) VALUES (154, 22, `Vat`, NULL, `Dr`., 152, NULL, NULL, NULL, NULL, NULL, NULL, 22, `2022-09-28` `08:41:47`, 25, `2022-09-28` `19:41:47`, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) DEFAULT NULL,
  `address` text,
  `pic` varchar(100) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `is_default` enum('1','0') NOT NULL DEFAULT '0',
  `permission` text NOT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `role_id` (`role_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `sch_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `is_default`, `permission`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (23, 20, `munna123@gmail`.`com`, `7c222fb2927d828af22f592134e8932480637c0d`, `Munna` `Store`, NULL, NULL, , 22, 1, 1, , 1, `2022-09-26` `08:23:15`, NULL, `2022-09-26` `19:23:36`, NULL, NULL);
INSERT INTO `users` (`user_id`, `sch_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `is_default`, `permission`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (24, 21, `abhasibul@gmail`.`com`, `7c222fb2927d828af22f592134e8932480637c0d`, `Hasib` `Store`, NULL, NULL, , 23, 1, 1, , 1, `2022-09-26` `08:25:24`, NULL, `2022-09-26` `19:26:10`, NULL, NULL);
INSERT INTO `users` (`user_id`, `sch_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `is_default`, `permission`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (25, 22, `sumon1@gmail`.`com`, `7c222fb2927d828af22f592134e8932480637c0d`, `Sumon` `Shop`, NULL, NULL, , 24, 1, 1, , 1, `2022-09-26` `08:49:10`, NULL, `2022-09-26` `19:49:32`, NULL, NULL);
INSERT INTO `users` (`user_id`, `sch_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `is_default`, `permission`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (26, 23, `murad@gmail`.`com`, `7c222fb2927d828af22f592134e8932480637c0d`, `Murad` `shop`, NULL, NULL, , 25, 1, 1, , 1, `2022-09-26` `10:58:18`, NULL, `2022-09-27` `09:58:37`, NULL, NULL);
INSERT INTO `users` (`user_id`, `sch_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `is_default`, `permission`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (28, 23, `maneger@gmail`.`com`, `7c222fb2927d828af22f592134e8932480637c0d`, `Maneger`, NULL, NULL, , 26, 1, 0, , 26, `2022-09-27` `12:52:12`, 26, `2022-09-27` `11:52:34`, NULL, NULL);
INSERT INTO `users` (`user_id`, `sch_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `is_default`, `permission`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (29, 24, `imran@dnationsoft`.`com`, `7c222fb2927d828af22f592134e8932480637c0d`, `Syed Imran` `Ertaza`, NULL, NULL, , 27, 1, 1, , 1, `2022-10-01` `12:22:37`, NULL, `2022-10-01` `11:55:58`, NULL, NULL);


#
# TABLE STRUCTURE FOR: vat_register
#

DROP TABLE IF EXISTS `vat_register`;

CREATE TABLE `vat_register` (
  `vat_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `vat_register_no` varchar(155) DEFAULT NULL,
  `balance` double NOT NULL,
  `is_default` enum('1','0') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`vat_id`),
  KEY `sch_id` (`sch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO `vat_register` (`vat_id`, `sch_id`, `name`, `vat_register_no`, `balance`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (20, 20, `Default Vat` `Name`, `BIN-0000-01`, `-24`.`69`, 1, `2022-09-26` `08:23:15`, 1, 23, `2022-09-28` `19:33:29`, NULL, NULL);
INSERT INTO `vat_register` (`vat_id`, `sch_id`, `name`, `vat_register_no`, `balance`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (21, 21, `Default Vat` `Name`, `BIN-0000-01`, 0, 1, `2022-09-26` `08:25:24`, 1, 24, `2022-10-01` `17:50:10`, NULL, NULL);
INSERT INTO `vat_register` (`vat_id`, `sch_id`, `name`, `vat_register_no`, `balance`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (22, 22, `Default Vat` `Name`, `BIN-0000-01`, 0, 1, `2022-09-26` `08:49:10`, 1, 25, `2022-09-28` `19:41:47`, NULL, NULL);
INSERT INTO `vat_register` (`vat_id`, `sch_id`, `name`, `vat_register_no`, `balance`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (23, 23, `Default Vat` `Name`, `BIN-0000-01`, `-0`.`23`, 1, `2022-09-26` `10:58:18`, 1, 26, `2022-09-27` `11:07:46`, NULL, NULL);
INSERT INTO `vat_register` (`vat_id`, `sch_id`, `name`, `vat_register_no`, `balance`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES (24, 24, `Default Vat` `Name`, `BIN-0000-01`, 0, 1, `2022-10-01` `12:22:37`, 1, NULL, `2022-10-01` `11:22:37`, NULL, NULL);


#
# TABLE STRUCTURE FOR: warranty_manage
#

DROP TABLE IF EXISTS `warranty_manage`;

CREATE TABLE `warranty_manage` (
  `warranty_id` int(11) NOT NULL AUTO_INCREMENT,
  `sch_id` int(11) NOT NULL,
  `product_name` varchar(55) NOT NULL,
  `receive_date` date NOT NULL,
  `delivery_date` date NOT NULL,
  `customer_address` varchar(55) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `mobile` int(11) NOT NULL,
  `createdDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int(11) NOT NULL,
  `updateDtm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL,
  PRIMARY KEY (`warranty_id`),
  KEY `sch_id` (`sch_id`),
  CONSTRAINT `warranty_manage_ibfk_1` FOREIGN KEY (`sch_id`) REFERENCES `shops` (`sch_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

