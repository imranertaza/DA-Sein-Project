<!doctype html>
<html lang="en-US">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#fff">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/swiper_5.3.0/css/swiper.min.css">
    <base href="">
    <title>DA-SEIN</title>
    <link rel="shortcut icon" type="image/x-icon"
          href="<?php echo base_url()?>/content/v1/51819b9fe4b03000ce6f03ea/1397468947522-8YU4E750PIJ9WVU9O4GZ/favicon.ico"/>
    <script type="text/javascript" src="<?php echo base_url()?>/scrip/JMJ7fbRAdsMgeM96MKG4fF4lIMIjgkMfH6qJuAXbMs6FJMJ7fbRsdsMgeMt6MKG4fFilIMIj2kMfH6qJXhXbMs6sJMHbMprKtGqe_q6y6qpiu5h7we7qzkax22p.js"></script>
    <script type="text/javascript">
        try {
            Typekit.load();
        } catch (e) {
        }
    </script>
    <script type="text/javascript" nomodule="nomodule" src="<?php echo base_url()?>/_sqs/polyfiller/1.2.2/legacy.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>/_sqs/polyfiller/1.2.2/modern.js"></script>
    <script type="text/javascript">SQUARESPACE_ROLLUPS = {};</script>
    <script>(function (rollups, name) {
            if (!rollups[name]) {
                rollups[name] = {};
            }
            rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/extract-css-runtime-36d0255dcceb439f1e9ba-min.en-US.js"];
        })(SQUARESPACE_ROLLUPS, 'squarespace-extract_css_runtime');</script>
    <script src="<?php echo base_url()?>/universal/scripts-compressed/extract-css-runtime-36d0255dcceb439f1e9ba-min.en-US.js"></script>
    <script>(function (rollups, name) {
            if (!rollups[name]) {
                rollups[name] = {};
            }
            rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/extract-css-moment-js-vendor-98bddc81dc37f44faa7b2-min.en-US.js"];
        })(SQUARESPACE_ROLLUPS, 'squarespace-extract_css_moment_js_vendor');</script>
    <script src="<?php echo base_url()?>/universal/scripts-compressed/extract-css-moment-js-vendor-98bddc81dc37f44faa7b2-min.en-US.js"></script>
    <script>(function (rollups, name) {
            if (!rollups[name]) {
                rollups[name] = {};
            }
            rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/cldr-resource-pack-83b0e6eb9a2c7557ad4c0-min.en-US.js"];
        })(SQUARESPACE_ROLLUPS, 'squarespace-cldr_resource_pack');</script>
    <script src="<?php echo base_url()?>/universal/scripts-compressed/cldr-resource-pack-83b0e6eb9a2c7557ad4c0-min.en-US.js"></script>
    <script>(function (rollups, name) {
            if (!rollups[name]) {
                rollups[name] = {};
            }
            rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/common-vendors-stable-9b2a74c45b27271fd111d-min.en-US.js"];
        })(SQUARESPACE_ROLLUPS, 'squarespace-common_vendors_stable');</script>
    <script src="<?php echo base_url()?>/universal/scripts-compressed/common-vendors-stable-9b2a74c45b27271fd111d-min.en-US.js"></script>
    <script>(function (rollups, name) {
            if (!rollups[name]) {
                rollups[name] = {};
            }
            rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/common-vendors-96bc8712c3745d2ebe37e-min.en-US.js"];
        })(SQUARESPACE_ROLLUPS, 'squarespace-common_vendors');</script>
    <script src="universal/scripts-compressed/common-vendors-96bc8712c3745d2ebe37e-min.en-US.js"></script>
    <script>(function (rollups, name) {
            if (!rollups[name]) {
                rollups[name] = {};
            }
            rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/common-7d2274e9405484b5bb8c6-min.en-US.js"];
        })(SQUARESPACE_ROLLUPS, 'squarespace-common');</script>
    <script src="universal/scripts-compressed/common-7d2274e9405484b5bb8c6-min.en-US.js"></script>
    <script>(function (rollups, name) {
            if (!rollups[name]) {
                rollups[name] = {};
            }
            rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/user-account-core-1b8bceaacbe4616b0d51b-min.en-US.js"];
        })(SQUARESPACE_ROLLUPS, 'squarespace-user_account_core');</script>
    <script src="<?php echo base_url()?>/universal/scripts-compressed/user-account-core-1b8bceaacbe4616b0d51b-min.en-US.js"></script>

    <script>
        (function (rollups, name) {
            if (!rollups[name]) {
                rollups[name] = {};
            }
            rollups[name].css = ["//assets.squarespace.com/universal/styles-compressed/user-account-core-68c2f27a2a82c80680342-min.en-US.css"];
        })(SQUARESPACE_ROLLUPS, 'squarespace-user_account_core');</script>
    <link rel="stylesheet" type="text/css"
          href="<?php echo base_url()?>/universal/styles-compressed/user-account-core-68c2f27a2a82c80680342-min.en-US.css">
    <script>(function (rollups, name) {
            if (!rollups[name]) {
                rollups[name] = {};
            }
            rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/performance-8b6f08d427d358ad6b72c-min.en-US.js"];
        })(SQUARESPACE_ROLLUPS, 'squarespace-performance');</script>
    <script src="<?php echo base_url()?>/universal/scripts-compressed/performance-8b6f08d427d358ad6b72c-min.en-US.js" defer></script>
    <script data-name="static-context">
        Static = window.Static || {};
        Static.SQUARESPACE_CONTEXT = {
            "facebookAppId": "314192535267336",
            "facebookApiVersion": "v6.0",
            "rollups": {
                "squarespace-announcement-bar": {"js": "universal/scripts-compressed/announcement-bar-58a6b009b4233b99452d8-min.en-US.js"},
                "squarespace-audio-player": {
                    "css": "universal/styles-compressed/audio-player-702bf18174efe0acaa8ce-min.en-US.css",
                    "js": "universal/scripts-compressed/audio-player-9a75241d2b6f78112fca9-min.en-US.js"
                },
                "squarespace-blog-collection-list": {
                    "css": "//assets.squarespace.com/universal/styles-compressed/blog-collection-list-3d55c64c25996c7633fc2-min.en-US.css",
                    "js": "universal/scripts-compressed/blog-collection-list-b44b4108e3cadfeb3bb28-min.en-US.js"
                },
                "squarespace-calendar-block-renderer": {
                    "css": "universal/styles-compressed/calendar-block-renderer-49c4a5f3dae67a728e3f4-min.en-US.css",
                    "js": "universal/scripts-compressed/calendar-block-renderer-063de1ad5ad80a214bc2d-min.en-US.js"
                },
                "squarespace-chartjs-helpers": {
                    "css": "universal/styles-compressed/chartjs-helpers-53c004ac7d4bde1c92e38-min.en-US.css",
                    "js": "universal/scripts-compressed/chartjs-helpers-63b813c7a9ec7be6db999-min.en-US.js"
                },
                "squarespace-comments": {
                    "css": "universal/styles-compressed/comments-91e23fb14e407e3111565-min.en-US.css",
                    "js": "universal/scripts-compressed/comments-3b45e5c309452ea741d5c-min.en-US.js"
                },
                "squarespace-dialog": {
                    "css": "universal/styles-compressed/dialog-89b254b5c87045b9e1360-min.en-US.css",
                    "js": "universal/scripts-compressed/dialog-c9a8abedf0af91ae92751-min.en-US.js"
                },
                "squarespace-events-collection": {
                    "css": "universal/styles-compressed/events-collection-49c4a5f3dae67a728e3f4-min.en-US.css",
                    "js": "universal/scripts-compressed/events-collection-ad209f2eea72403faa8f9-min.en-US.js"
                },
                "squarespace-form-rendering-utils": {"js": "universal/scripts-compressed/form-rendering-utils-b1d5d65641788de3cf4de-min.en-US.js"},
                "squarespace-forms": {
                    "css": "universal/styles-compressed/forms-4a16a8a8c965386db2173-min.en-US.css",
                    "js": "universal/scripts-compressed/forms-97f84da9fc6455c0dce66-min.en-US.js"
                },
                "squarespace-gallery-collection-list": {
                    "css": "//assets.squarespace.com/universal/styles-compressed/gallery-collection-list-3d55c64c25996c7633fc2-min.en-US.css",
                    "js": "universal/scripts-compressed/gallery-collection-list-a275e058377feac127abb-min.en-US.js"
                },
                "squarespace-image-zoom": {
                    "css": "universal/styles-compressed/image-zoom-8804675084a3982b022e3-min.en-US.css",
                    "js": "universal/scripts-compressed/image-zoom-7817bbf3299a0b654acc4-min.en-US.js"
                },
                "squarespace-pinterest": {
                    "css": "//assets.squarespace.com/universal/styles-compressed/pinterest-3d55c64c25996c7633fc2-min.en-US.css",
                    "js": "universal/scripts-compressed/pinterest-ac1b1bff95d1613e7cea4-min.en-US.js"
                },
                "squarespace-popup-overlay": {
                    "css": "universal/styles-compressed/popup-overlay-948192219c3257f767ec5-min.en-US.css",
                    "js": "universal/scripts-compressed/popup-overlay-2dd5c78ce532525922243-min.en-US.js"
                },
                "squarespace-product-quick-view": {
                    "css": "universal/styles-compressed/product-quick-view-5d6c4f164c4ab5457107a-min.en-US.css",
                    "js": "universal/scripts-compressed/product-quick-view-4f2e85c5e0b34204bd50c-min.en-US.js"
                },
                "squarespace-products-collection-item-v2": {
                    "css": "universal/styles-compressed/products-collection-item-v2-8804675084a3982b022e3-min.en-US.css",
                    "js": "universal/scripts-compressed/products-collection-item-v2-042671796c87a5a02797e-min.en-US.js"
                },
                "squarespace-products-collection-list-v2": {
                    "css": "universal/styles-compressed/products-collection-list-v2-8804675084a3982b022e3-min.en-US.css",
                    "js": "universal/scripts-compressed/products-collection-list-v2-68e682b0629ed86541771-min.en-US.js"
                },
                "squarespace-search-page": {
                    "css": "universal/styles-compressed/search-page-9d0a55de1efafbb9218e1-min.en-US.css",
                    "js": "universal/scripts-compressed/search-page-68fa3c1135f9072191668-min.en-US.js"
                },
                "squarespace-search-preview": {"js": "universal/scripts-compressed/search-preview-46e11810a59e11b7e4b49-min.en-US.js"},
                "squarespace-simple-liking": {
                    "css": "universal/styles-compressed/simple-liking-ef94529873378652e6e86-min.en-US.css",
                    "js": "universal/scripts-compressed/simple-liking-599ed48f406bb7fd00d1a-min.en-US.js"
                },
                "squarespace-social-buttons": {
                    "css": "universal/styles-compressed/social-buttons-1f18e025ea682ade6293a-min.en-US.css",
                    "js": "universal/scripts-compressed/social-buttons-1bbb33b7960a74025a462-min.en-US.js"
                },
                "squarespace-tourdates": {
                    "css": "//assets.squarespace.com/universal/styles-compressed/tourdates-3d55c64c25996c7633fc2-min.en-US.css",
                    "js": "universal/scripts-compressed/tourdates-a0585d7b8dcd9b6fc9891-min.en-US.js"
                },
                "squarespace-website-overlays-manager": {
                    "css": "universal/styles-compressed/website-overlays-manager-7cecc648f858e6f692130-min.en-US.css",
                    "js": "universal/scripts-compressed/website-overlays-manager-ddf855989db2c1dd04fe9-min.en-US.js"
                }
            },
            "pageType": 1,
            "website": {
                "id": "51819b9fe4b03000ce6f03ea",
                "identifier": "DA-SEIN",
                "websiteType": 1,
                "contentModifiedOn": 1667900094058,
                "cloneable": false,
                "hasBeenCloneable": false,
                "developerMode": true,
                "siteStatus": {},
                "language": "en-US",
                "timeZone": "Europe/Copenhagen",
                "machineTimeZoneOffset": 3600000,
                "timeZoneOffset": 3600000,
                "timeZoneAbbr": "CET",
                "siteTitle": "DA-SEIN",
                "fullSiteTitle": "DA-SEIN",
                "siteDescription": "<p>DA-sein is a Copenhagen-based office practicing in the fields of modern architecture, design and visionary urban development and planning.</p>",
                "location": {
                    "mapZoom": 11.0,
                    "mapLat": 55.68242600801169,
                    "mapLng": 12.559878645507734,
                    "markerLat": 55.68745819999999,
                    "markerLng": 12.559191999999939,
                    "addressTitle": "DA-SEIN",
                    "addressLine1": "Bl\u00E5g\u00E5rdsgade 8, 2. sal",
                    "addressLine2": "K\u00F8benhavn",
                    "addressCountry": "Denmark"
                },
                "shareButtonOptions": {"1": true, "2": true, "4": true},
                "authenticUrl": "",
                "internalUrl": "https://DA-SEIN.squarespace.com",
                "baseUrl": "",
                "primaryDomain": "www.DA-SEIN",
                "sslSetting": 3,
                "isHstsEnabled": true,
                "socialAccounts": [{
                    "serviceId": 14,
                    "userId": "8katVC5I9N",
                    "userName": "mikkelbogh",
                    "screenname": "Mikkel B\u00F8gh",
                    "addedOn": 1394096506531,
                    "profileUrl": "http://www.linkedin.com/company/DA-SEIN",
                    "iconUrl": "http://m.c.lnkd.licdn.com/mpr/mprx/0_ZPIPybcmqcS8pQkaZKV8yX6T4-EfyQLaVA02yXkYFAY0_G-mqvRx-krK9sor0TXGMKdSP_sdKWno",
                    "iconEnabled": true,
                    "serviceName": "linkedin"
                }, {
                    "serviceId": 2,
                    "userId": "589822749",
                    "userName": "mikkelbogh",
                    "screenname": "DA-SEIN",
                    "addedOn": 1387538646758,
                    "profileUrl": "http://www.facebook.com/DA-SEIN",
                    "iconUrl": "http://graph.facebook.com/589822749/picture?type=square",
                    "metaData": {"service": "facebook"},
                    "iconEnabled": true,
                    "serviceName": "facebook"
                }, {
                    "serviceId": 4,
                    "userId": "2709409596",
                    "userName": "EffektArch",
                    "screenname": "DA-SEIN Architects",
                    "addedOn": 1454421501103,
                    "profileUrl": "https://twitter.com/EffektArch",
                    "iconUrl": "profile_images/537949652255920129/SuY_ivPV_normal.jpg",
                    "collectionId": "56b0b5fd27d4bda6674f1092",
                    "iconEnabled": true,
                    "serviceName": "twitter"
                }, {
                    "serviceId": 64,
                    "screenname": "Instagram",
                    "addedOn": 1612792401475,
                    "profileUrl": "http://instagram.com/DA-SEINarchitects",
                    "iconEnabled": true,
                    "serviceName": "instagram-unauth"
                }, {
                    "serviceId": 61,
                    "screenname": "Pinterest",
                    "addedOn": 1624965462721,
                    "profileUrl": "http://pinterest.com/DA-SEINarchitects",
                    "iconEnabled": true,
                    "serviceName": "pinterest-unauth"
                }, {
                    "serviceId": 68,
                    "screenname": "Vimeo",
                    "addedOn": 1624965491947,
                    "profileUrl": "http://vimeo.com/DA-SEINarchitects",
                    "iconEnabled": true,
                    "serviceName": "vimeo-unauth"
                }],
                "typekitId": "",
                "statsMigrated": true,
                "imageMetadataProcessingEnabled": false,
                "screenshotId": "6b8f53a6516d137fb027e1c70c8fbc2fbac7e29c3621e07ea2970fb4757cf65a",
                "showOwnerLogin": false
            },
            "websiteSettings": {
                "id": "51819b9fe4b03000ce6f03eb",
                "websiteId": "51819b9fe4b03000ce6f03ea",
                "type": "Business",
                "subjects": [{"systemSubject": "other", "otherSubject": "Architecture Services"}],
                "country": "DK",
                "state": "AL",
                "simpleLikingEnabled": false,
                "mobileInfoBarSettings": {
                    "style": 1,
                    "isContactEmailEnabled": false,
                    "isContactPhoneNumberEnabled": false,
                    "isLocationEnabled": false,
                    "isBusinessHoursEnabled": false
                },
                "announcementBarSettings": {
                    "style": 1,
                    "text": "<p class=\"\" style=\"white-space:pre-wrap;\">DA-SEIN exhibits at la Biennale di Architettura Venezia</p>",
                    "clickthroughUrl": {"url": "/biennale", "newWindow": false}
                },
                "popupOverlaySettings": {
                    "style": 2,
                    "showOnScroll": true,
                    "scrollPercentage": 25,
                    "showOnTimer": true,
                    "timerDelay": 0,
                    "showUntilSignup": true,
                    "displayFrequency": 30,
                    "enableMobile": true,
                    "enabledPages": [],
                    "showOnAllPages": true,
                    "version": 1
                },
                "commentLikesAllowed": false,
                "commentAnonAllowed": false,
                "commentThreaded": false,
                "commentApprovalRequired": false,
                "commentAvatarsOn": false,
                "commentSortType": 2,
                "commentFlagThreshold": 0,
                "commentFlagsAllowed": false,
                "commentEnableByDefault": false,
                "commentDisableAfterDaysDefault": 0,
                "disqusShortname": "",
                "commentsEnabled": false,
                "contactPhoneNumber": "+45 3535 3631",
                "businessHours": {
                    "monday": {"text": "9am to 5pm", "ranges": [{"from": 540, "to": 1020}]},
                    "tuesday": {"text": "9am to 5pm", "ranges": [{"from": 540, "to": 1020}]},
                    "wednesday": {"text": "9am to 5pm", "ranges": [{"from": 540, "to": 1020}]},
                    "thursday": {"text": "9am to 5pm", "ranges": [{"from": 540, "to": 1020}]},
                    "friday": {"text": "9am to 5pm", "ranges": [{"from": 540, "to": 1020}]}
                },
                "storeSettings": {
                    "returnPolicy": null,
                    "termsOfService": null,
                    "privacyPolicy": null,
                    "expressCheckout": false,
                    "continueShoppingLinkUrl": "/",
                    "useLightCart": false,
                    "showNoteField": false,
                    "shippingCountryDefaultValue": "US",
                    "billToShippingDefaultValue": false,
                    "showShippingPhoneNumber": false,
                    "isShippingPhoneRequired": false,
                    "showBillingPhoneNumber": false,
                    "isBillingPhoneRequired": false,
                    "currenciesSupported": ["CHF", "HKD", "MXN", "EUR", "DKK", "USD", "CAD", "MYR", "NOK", "THB", "AUD", "SGD", "ILS", "PLN", "GBP", "CZK", "SEK", "NZD", "PHP", "RUB"],
                    "defaultCurrency": "USD",
                    "selectedCurrency": "USD",
                    "measurementStandard": 1,
                    "showCustomCheckoutForm": false,
                    "checkoutPageMarketingOptInEnabled": false,
                    "enableMailingListOptInByDefault": true,
                    "sameAsRetailLocation": false,
                    "merchandisingSettings": {
                        "scarcityEnabledOnProductItems": false,
                        "scarcityEnabledOnProductBlocks": false,
                        "scarcityMessageType": "DEFAULT_SCARCITY_MESSAGE",
                        "scarcityThreshold": 10,
                        "multipleQuantityAllowedForServices": true,
                        "restockNotificationsEnabled": false,
                        "restockNotificationsMailingListSignUpEnabled": false,
                        "relatedProductsEnabled": false,
                        "relatedProductsOrdering": "random",
                        "soldOutVariantsDropdownDisabled": false,
                        "productComposerOptedIn": false,
                        "productComposerABTestOptedOut": false,
                        "productReviewsEnabled": false,
                        "displayImportedProductReviewsEnabled": false,
                        "hasOptedToCollectNativeReviews": false
                    },
                    "isLive": false,
                    "multipleQuantityAllowedForServices": true
                },
                "useEscapeKeyToLogin": false,
                "ssBadgeType": 1,
                "ssBadgePosition": 4,
                "ssBadgeVisibility": 1,
                "ssBadgeDevices": 1,
                "pinterestOverlayOptions": {"mode": "disabled", "size": "small", "shape": "rect", "color": "white"},
                "ampEnabled": true
            },
            "cookieSettings": {
                "isCookieBannerEnabled": false,
                "isRestrictiveCookiePolicyEnabled": false,
                "isRestrictiveCookiePolicyAbsolute": false,
                "cookieBannerText": "",
                "cookieBannerTheme": "",
                "cookieBannerVariant": "",
                "cookieBannerPosition": "",
                "cookieBannerCtaVariant": "",
                "cookieBannerCtaText": "",
                "cookieBannerAcceptType": "OPT_IN",
                "cookieBannerOptOutCtaText": ""
            },
            "websiteCloneable": false,
            "collection": {
                "title": "Frontpage",
                "id": "59f10dc91f318dc4a4211a4f",
                "fullUrl": "/",
                "type": 1,
                "permissionType": 1
            },
            "subscribed": false,
            "appDomain": "squarespace.com",
            "templateTweakable": true,
            "tweakJSON": {
                "product-gallery-auto-crop": "true",
                "product-image-auto-crop": "true",
                "tweak-blog-item-gutter": "1.5rem",
                "tweak-blog-item-height": "184px",
                "tweak-blog-item-width": "300px",
                "tweak-grid-item-gutter": "1.5rem",
                "tweak-grid-item-height": "230px",
                "tweak-grid-item-width": "425px",
                "tweak-list-item-gutter": "1.5rem",
                "tweak-list-item-height": "136.9px",
                "tweak-list-item-width": "243.43px",
                "tweak-v1-related-products-title-spacing": "50px"
            },
            "templateId": "59efd49429f187a715e40c1b",
            "templateVersion": "7",
            "pageFeatures": [1, 2, 4],
            "gmRenderKey": "QUl6YVN5Q0JUUk9xNkx1dkZfSUUxcjQ2LVQ0QWVUU1YtMGQ3bXk4",
            "templateScriptsRootUrl": "https://static1.squarespace.com/static/ta/51819b9fe4b03000ce6f03ea/100/scripts/",
            "betaFeatureFlags": ["campaigns_new_image_layout_picker", "fluid_engine_filtered_catalog_endpoints", "commerce_order_status_access", "background_art_onboarding", "commerce_etsy_shipping_import", "fluid_engine_clean_up_grid_contextual_change", "campaigns_show_featured_templates", "campaigns_thumbnail_layout", "customer_accounts_email_verification", "member_areas_feature", "asset_uploader_refactor", "fluid_engine_block_resizing_indicator", "campaigns_global_uc_ab", "member_areas_schedule_interview", "member_areas_spanish_interviews", "campaigns_new_subscriber_search", "crm_remove_subscriber", "commerce_etsy_product_import", "commerce_restock_notifications", "block_annotations_revamp", "fluid_engine", "nested_categories_migration_enabled", "crm_use_new_import_modal_profiles", "customer_account_creation_recaptcha", "crm_retention_segment", "campaigns_content_editing_survey", "campaigns_discount_section_in_blasts", "block_duplication", "marketing_landing_page", "scheduling_block_schema_editor", "commerce_site_visitor_metrics", "campaigns_asset_picker", "send_local_pickup_ready_email", "crm_default_newsletter_block_to_campaigns", "viewer-role-contributor-invites", "commerce_clearpay"],
            "videoAssetsFeatureFlags": ["hls-playback", "mux-data-video-collection"],
            "impersonatedSession": false,
            "tzData": {
                "zones": [[60, "EU", "CE%sT", null]],
                "rules": {"EU": [[1981, "max", null, "Mar", "lastSun", "1:00u", "1:00", "S"], [1996, "max", null, "Oct", "lastSun", "1:00u", "0", null]]}
            },
            "showAnnouncementBar": false
        };</script>
    <script>SquarespaceFonts.loadViaContext();
        Squarespace.load(window);</script>
    <script type="application/ld+json">{
        "url": "",
        "name": "DA-SEIN",
        "description": "<p>DA-SEIN is a Copenhagen-based office practicing in the fields of modern architecture, design and visionary urban development and planning.</p><p>Bl\u00E5g\u00E5rdsgade 8, 2. sal, DK-2200 K\u00F8benhavn N, Tlf. (+45) 3535 3631</p>",
        "@context": "http://schema.org",
        "@type": "WebSite"
    }</script>
    <script type="application/ld+json">{
        "legalName": "DA-SEIN",
        "address": "Bl\u00E5g\u00E5rdsgade 8, 2. sal\nK\u00F8benhavn\nDenmark",
        "email": "hello@DA-SEIN",
        "telephone": "+45 3535 3631",
        "sameAs": [
            "http://www.linkedin.com/company/DA-SEIN",
            "http://www.facebook.com/DA-SEIN",
            "https://twitter.com/EffektArch",
            "http://instagram.com/DA-SEINarchitects",
            "http://pinterest.com/DA-SEINarchitects",
            "http://vimeo.com/DA-SEINarchitects"
        ],
        "@context": "http://schema.org",
        "@type": "Organization"
    }</script>
    <script type="application/ld+json">{
        "address": "Bl\u00E5g\u00E5rdsgade 8, 2. sal\nK\u00F8benhavn\nDenmark",
        "name": "DA-SEIN",
        "openingHours": "Mo 09:00-17:00, Tu 09:00-17:00, We 09:00-17:00, Th 09:00-17:00, Fr 09:00-17:00",
        "@context": "http://schema.org",
        "@type": "LocalBusiness"
    }</script>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/css/100/site.css"/>
    <script>Static.COOKIE_BANNER_CAPABLE = true;</script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=$GA_TRACKING_ID$"></script>
    <script>window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }

        gtag('js', new Date());
        gtag('set', 'developer_id.dZjQwMz', true);
        gtag('config', 'UA-40686607-1');</script><!-- End of Squarespace Headers -->
</head>
<body id="collection-59f10dc91f318dc4a4211a4f"
      class="product-list-titles-overlay product-list-alignment-center product-item-size-11-square product-image-auto-crop product-gallery-size-11-square product-gallery-auto-crop show-product-price show-product-item-nav product-social-sharing tweak-v1-related-products-image-aspect-ratio-11-square tweak-v1-related-products-details-alignment-center newsletter-style-dark hide-opentable-icons opentable-style-light small-button-style-solid small-button-shape-square medium-button-style-outline medium-button-shape-square large-button-style-solid large-button-shape-square image-block-poster-text-alignment-center image-block-card-dynamic-font-sizing image-block-card-content-position-center image-block-card-text-alignment-left image-block-overlap-dynamic-font-sizing image-block-overlap-content-position-center image-block-overlap-text-alignment-left image-block-collage-dynamic-font-sizing image-block-collage-content-position-top image-block-collage-text-alignment-left image-block-stack-dynamic-font-sizing image-block-stack-text-alignment-left button-style-outline button-corner-style-square tweak-product-quick-view-button-style-floating tweak-product-quick-view-button-position-bottom tweak-product-quick-view-lightbox-excerpt-display-truncate tweak-product-quick-view-lightbox-show-arrows tweak-product-quick-view-lightbox-show-close-button tweak-product-quick-view-lightbox-controls-weight-light product-list-titles-overlay product-list-alignment-center product-item-size-11-square product-image-auto-crop product-gallery-size-11-square product-gallery-auto-crop show-product-price show-product-item-nav product-social-sharing tweak-v1-related-products-details-alignment-center native-currency-code-usd collection-type-index collection-layout-default collection-59f10dc91f318dc4a4211a4f homepage view-list">
<header class="site-header">
    <nav class="site-nav">
        <div class="logo-container">
            <a class="logo" href="<?php echo base_url()?>/" data-content-field="site-title">
                <img src="<?php echo base_url()?>/uploads/da_logo_white.png" alt="" width="100" class="img-fluid">
            </a>
        </div>
        <div class="nav-container">
            <!-- Desktop  Nav -->
            <ul class="main-nav">
                <li>
                    <a href="<?php echo base_url()?>/Home/news">News</a>
                </li>
                <li>
                    <a href="<?php echo base_url()?>/Home/work">Work</a>
                </li>
                <li>
                    <a href="<?php echo base_url()?>/Home/office">Office</a>
                </li>
            </ul>
            <!-- Mobile  Trigger -->
            <div class="hamburger hamburger--spring" tabindex="0" aria-label="Menu" role="button"
                 aria-controls="navigation" uk-toggle="target: .mobile-nav-wrapper">
                <div class="hamburger-box">
                    <div class="hamburger-inner"></div>
                </div>
            </div>
        </div>
    </nav>
    <div class="mobile-nav-wrapper uk-modal-full" uk-modal>
        <ul class="mobile-nav">
            <li>
                <a href="<?php echo base_url()?>/Home/news">News</a>
            </li>
            <li>
                <a href="<?php echo base_url()?>/Home/work">Work</a>
            </li>
            <li>
                <a href="<?php echo base_url()?>/Home/office">Office</a>
            </li>
        </ul>
    </div>
    <nav class="trans-nav">
        <div class="trans-nav-wrapper">
            <ul class="anchor-nav">
            </ul>
        </div>
    </nav>
</header>