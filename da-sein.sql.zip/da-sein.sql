-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2023 at 03:30 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `da-sein`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `country` varchar(155) DEFAULT NULL,
  `comName` varchar(155) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `country`, `comName`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'imranertaza12@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'DA-SEIN', 1924329315, 'Noapara, Abhaynagar, Jessore', 'profile_1668423086_1767251b95851b1d3769.jpg', 'Bangladesh', 'zzzzz', 1, '1', 1, '2018-11-21 18:05:40', 1, '2022-11-14 17:58:27', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `applied_position`
--

CREATE TABLE `applied_position` (
  `applied_position_id` int(11) NOT NULL,
  `applied_position_name` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applied_position`
--

INSERT INTO `applied_position` (`applied_position_id`, `applied_position_name`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Design Lead / Sagsarkitekt (10+ Years Experience)', 1, '2022-12-20 10:51:23', NULL, NULL),
(2, 'Project Manager (10+ Years Experience)', 1, '2022-12-20 10:51:32', NULL, NULL),
(3, 'Project Manager (5-10 Years Experience)', 1, '2022-12-20 10:51:44', NULL, NULL),
(4, 'Senior Architect (8+ Years Experience)', 1, '2022-12-20 10:51:51', NULL, NULL),
(5, 'Architect (5-7 Years Experience) *', 1, '2022-12-20 10:51:59', NULL, NULL),
(6, 'Architect (0-4 Years Experience) *', 1, '2022-12-20 10:52:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `awards`
--

CREATE TABLE `awards` (
  `award_id` int(11) NOT NULL,
  `award_title` text NOT NULL,
  `award_title_url` text NOT NULL,
  `short_title` varchar(155) NOT NULL,
  `short_title_url` varchar(155) NOT NULL,
  `year` year(4) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `awards`
--

INSERT INTO `awards` (`award_id`, `award_title`, `award_title_url`, `short_title`, `short_title_url`, `year`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, '3rd place winner (JV) of the IAB Open Architectural Design competition for the design of Commercial Green Building\'', 'IAB Award', 'IAB Award', 'IAB Award', 2018, '1', 1, '2022-11-28 12:21:03', 1, '2022-11-28 12:21:03'),
(2, 'Berger Design Awards', 'Berger Design Awards', 'Berger Design Awards', 'Berger Design Awards', 2021, '1', 1, '2022-11-28 12:21:39', 1, '2022-11-28 12:21:39'),
(3, '2nd place winner (JV) of the IAB Open Architectural Design Competition for the Head Office for Bangladesh Energy Regulatory Commission (BERC),', 'http://www.iab.com.bd', 'BERC Project', 'http://www.iab.com.bd', 2019, '1', 1, '2022-11-28 12:22:20', 1, '2022-11-28 12:22:20');

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

CREATE TABLE `blocks` (
  `block_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `description` text DEFAULT NULL,
  `page_type` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blocks`
--

INSERT INTO `blocks` (`block_id`, `title`, `description`, `page_type`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'profile', '<h1>Da-sein founded in 2004 is a design and research studio based in Dhaka, Bangladesh.</h1>\r\n', '1', 1, '2022-12-10 20:36:55', 1, NULL),
(2, 'profile', '<h1>Da-sein&nbsp;is a&nbsp;German&nbsp;word that means &#39;Existence&#39;. &nbsp;&ldquo;Being in the world&rdquo;</h1>\r\n', '1', 1, '2022-12-10 20:37:15', 1, NULL),
(3, 'profile', '<h1>Da-sein provides solutions and services within the built environment and the natural systems that sustain us.</h1>\r\n', '1', 1, '2022-12-10 20:37:35', 1, NULL),
(4, 'profile', '<h1>Da-sein has a talented group of designers, architects, urban planners, landscape architects, and other professionals on its ambitious team.</h1>\r\n', '1', 1, '2022-12-10 20:37:52', 1, NULL),
(6, 'Address', '<p><strong>DA-SEIN Architects</strong></p>\r\n\r\n<p>Unit: 2A, House: 59, Road 7A,</p>\r\n\r\n<p>Dhanmond, Dhaka-1209.<br />\r\n<br />\r\nTel. (+88) 01711937254<br />\r\nE-mail&nbsp;<a href=\"mailto:hello@da-sein.org\">hello@da-sein.c</a>om<br />\r\nDa-sein, is a IAB Registered Architectural &nbsp; &nbsp; Consultants .IAB Registration: <strong>IAB-RP-D11</strong></p>\r\n', '2', 1, '2022-12-11 10:36:29', 1, NULL),
(7, 'Insurance', '<p><strong>Delta Life Insurance Company Limited</strong></p>\r\n\r\n<p>Delta Life Tower<br />\r\nPlot # 37, Road # 90, Gulshan Circle &ndash; 2, Dhaka &ndash; 1212.<br />\r\nTelephone: +88 02 5505 1019, 09613 666 000 (PABX), Fax: +88 02 883 1739<br />\r\ne-mail:&nbsp;<a href=\"mailto:mdsecretariat@deltalife.org\">mdsecretariat@deltalife.org</a>,&nbsp;<a href=\"mailto:info@deltalife.org\">info@deltalife.org</a><br />\r\n<br />\r\nPolicy no.:<br />\r\n0000000000</p>\r\n', '2', 1, '2022-12-11 10:36:46', 1, NULL),
(8, 'Bank', '<p><strong>Standard Chartered Bank</strong></p>\r\n\r\n<p>Dhanmondi Branch<br />\r\nHouse 6, Road 5, Dhanmondi R/A, Dhaka 1205<br />\r\nBranch Code 124<br />\r\nSWIFT Code : SCBLBDDX<br />\r\nRouting Number: 215261247</p>\r\n\r\n<p>District: Dhaka<br />\r\nWorking Days: Sunday - Thursday (Except Holidays)<br />\r\n&nbsp;</p>\r\n', '2', 1, '2022-12-11 10:37:02', 1, NULL),
(9, 'Business Development', '<p>For new business and project inquiries, please contact:</p>\r\n\r\n<p><strong>Rashidur Rahman</strong><br />\r\nDirector of Business Development<br />\r\n<a href=\"mailto:jz@da-sein.org\">i</a>nfo@da-sein.com</p>\r\n', '2', 1, '2022-12-11 10:37:19', 1, NULL),
(10, 'Press & Communication', '<p><strong>Mehehi Shawon</strong><br />\r\nCommunication Manager<br />\r\n<a href=\"mailto:lb@da-sein.org\" target=\"_blank\">Mehedi@da-sein.c</a>om</p>\r\n', '2', 1, '2022-12-11 10:37:33', 1, NULL),
(11, 'Lectures & speaking engagements', '<p>To request a lecture or to engage DA-SEIN in speaking engagements, panel debates, conferences, etc. kindly fill out&nbsp;<a href=\"http://test.dns/da_sein/public/Home/office#\" target=\"_blank\">this form</a>&nbsp;to submit a request.<br />\r\n<br />\r\nIf you have additional material to support you request please attach it at the end of the form.</p>\r\n', '2', 1, '2022-12-11 10:37:50', NULL, NULL),
(12, 'Jobs', '<p>All applications (solicited and unsolicited) should be submitted through our application system below .<br />\r\n<br />\r\nWe review all applications on a bi-weekly basis and store relevant applications for a maximum period of 6 months after which they are deleted.<br />\r\n<br />\r\nSubmitted files should be in .pdf format only and not exceed a size of 10 Mb.<br />\r\n<br />\r\nFor more information about working at da-sein.com please visit:</p>\r\n', '3', 1, '2022-12-11 10:55:46', 1, NULL),
(13, 'Internship', '<p>We are always looking for talented students of architecture, landscape architecture, urban planning, and constructing architects to join our team.</p>\r\n\r\n<p>We accept 6 - 8 interns during the spring and the fall semester, which run from August through January and from February through June.<br />\r\n<br />\r\nWe do not offer summer internships.</p>\r\n\r\n<p>We are currently receiving applications the following semesters :</p>\r\n\r\n<ul>\r\n	<li>\r\n	<p>Spring 2023&nbsp;<em>(February 6.2023 - July 14. 2023)</em></p>\r\n	</li>\r\n	<li>\r\n	<p>Fall 2023&nbsp;<em>(August 7. 2023 - January 31. 2024)</em></p>\r\n	</li>\r\n</ul>\r\n', '3', 1, '2022-12-11 10:56:01', 1, NULL),
(17, 'Holistic', '<h1>Da-sein combines a holistic and systemic design approach with human-scale design sensitivity and focuses on end-user experience.</h1>\r\n', '1', 1, '2023-02-07 22:28:55', 1, NULL),
(18, 'Profile', '<h1>Da-sein has remained committed to the notion of architecture as a form of plastic sculptural art. The search for form is a preoccupation of the design approach. Distinct forms, pure shapes, and clear lines form the basis of the Dasein design language.</h1>\r\n\r\n<h1>Da-sein&#39;s design process begins with close analysis, followed by complete involvement at every stage of the development of the project. Da-sein&#39;s approaches reflect critical and logical thinking about aspects of modern architecture.</h1>\r\n', '1', 1, '2023-02-07 22:44:13', 1, NULL),
(19, 'Profile', '<h1>Da-sein combines a subjective approach to prevailing site conditions and an objective analysis of the project brief. Free-hand sketching, computer modeling mock-ups, and model making is the basis of the design process.</h1>\r\n', '1', 1, '2023-02-07 22:45:41', 1, NULL),
(20, 'profile', '<h1>Da-sein remains committed to the notion that architecture is predicated on simplicity with clarity of form, transparency of spaces, and articulation of structure.</h1>\r\n\r\n<h1>Da-sein seeks to minimize the negative environmental impact of buildings through efficiency and moderation in the use of materials, energy, ecological conservation, and development space.</h1>\r\n', '1', 1, '2023-02-07 22:47:19', 1, NULL),
(21, 'Profile', '<h1>Da-sein is not a traditional office: a rigid and closed core, but a flexible organization that admits collaborations and partnerships according to the work to be developed. It is a space open to the participation of other architects and other professionals interested in the discussion about the production of living spaces and spaces of the city.</h1>\r\n\r\n<h1>Da-sein has done a good number of projects, built and unbuilt. Works range from individual houses, apartments, resorts, offices, and commercial buildings to master planning projects. While the smaller projects offer insights into aspects of material and detailing, the larger ones provide opportunities to probe issues of scale and form.</h1>\r\n', '1', 1, '2023-02-07 22:48:00', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `status` enum('0','1') DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `name`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Commercial', '1', 1, '2022-11-30 12:25:06', NULL, NULL),
(2, 'Residential', '1', 1, '2022-11-30 12:25:14', NULL, NULL),
(3, 'Civic ', '1', 1, '2022-11-30 12:25:29', 1, NULL),
(4, 'Conservation', '1', 1, '2022-11-30 12:25:39', NULL, NULL),
(5, 'Landscape', '1', 1, '2022-11-30 12:25:46', NULL, NULL),
(7, 'Product Design', '1', 1, '2023-02-14 19:11:58', 1, NULL),
(8, 'Urban Design', '1', 1, '2023-02-22 18:25:25', NULL, NULL),
(9, 'Hospitality', '1', 1, '2023-02-22 18:26:03', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `citizenship`
--

CREATE TABLE `citizenship` (
  `citizenship_id` int(11) NOT NULL,
  `citizenship_name` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `citizenship`
--

INSERT INTO `citizenship` (`citizenship_id`, `citizenship_name`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Banglasedhi Citizenship', 1, '2022-12-18 11:25:16', 1, NULL),
(2, 'Citizen other than Bangladesh', 1, '2022-12-18 11:25:37', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` int(11) NOT NULL,
  `logo` varchar(155) NOT NULL,
  `url` varchar(155) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `logo`, `url`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'people_1679538760_aeb8b0e1503e4f299396.bin', 'https://www.idcol.org', '1', 1, '2022-11-28 10:43:21', 1, '2022-11-28 10:43:21'),
(2, 'people_1679545361_56409574c043db77bdf5.jpg', 'https://www.grameenphone.com', '1', 1, '2022-11-28 10:43:29', 1, '2022-11-28 10:43:29'),
(3, 'people_1679539260_43818aed35192ddc40cc.jpg', 'https://logovtor.com/banglalink-logo-vector-svg/', '1', 1, '2022-11-28 10:43:34', 1, '2022-11-28 10:43:34'),
(8, 'people_1679544073_49a7b5d4144d8ecce5a5.jpg', 'SDSDS', '1', 1, '2023-03-23 09:56:38', 1, '2023-03-23 09:56:38'),
(9, 'client_1679545041_ea7bcec0dc3dc15e543c.jpg', 'hhh', '1', 1, '2023-03-23 10:17:21', NULL, '2023-03-23 10:17:21'),
(10, 'people_1679594065_65a2a07251a1f61e210f.jpg', 'https://olympiccement.com', '1', 1, '2023-03-23 23:52:31', 1, '2023-03-23 23:52:31'),
(11, 'client_1679594278_9a437da76395de7d4339.jpg', 'www.amazinggadgets.com', '1', 1, '2023-03-23 23:57:58', NULL, '2023-03-23 23:57:58'),
(12, 'people_1681154156_4c7aa754352a98fb76d3.jpg', 'https://www.texmartonline.com', '1', 1, '2023-03-24 00:02:10', 1, '2023-03-24 00:02:10'),
(13, 'people_1679595198_eafb0b4f191ea037aa7e.jpg', 'www.anandagroup.biz', '1', 1, '2023-03-24 00:11:40', 1, '2023-03-24 00:11:40'),
(14, 'client_1679595479_449f46b1e24acb9dd92d.jpg', 'www.anandagroup.biz', '1', 1, '2023-03-24 00:17:59', NULL, '2023-03-24 00:17:59'),
(15, 'people_1679782212_a656d78d25167023c2db.jpg', 'http://www.berc.org.bd', '1', 1, '2023-03-26 04:07:20', 1, '2023-03-26 04:07:20'),
(16, 'people_1681520515_070d654cca082ce44de0.jpg', 'ju', '1', 1, '2023-04-15 07:00:35', 1, '2023-04-15 07:00:35'),
(17, 'client_1681520810_91aba98c2f34273fd485.jpg', 'Dhaka University', '1', 1, '2023-04-15 07:06:50', NULL, '2023-04-15 07:06:50'),
(18, 'client_1681780197_7f14824053a109b47f34.jpg', 'ARTISTI COLLECTION', '1', 1, '2023-04-18 07:09:57', NULL, '2023-04-18 07:09:57');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `country_name`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(2, 'Afghanistan', 1, '2022-12-13 20:35:48', NULL, NULL),
(3, 'Albania', 1, '2022-12-13 20:35:54', NULL, NULL),
(4, 'Algeria', 1, '2022-12-13 20:36:00', NULL, NULL),
(5, 'Andorra', 1, '2022-12-13 20:36:06', NULL, NULL),
(6, 'Angola', 1, '2022-12-13 20:36:12', NULL, NULL),
(7, 'Antigua and Barbuda', 1, '2022-12-13 20:42:09', NULL, NULL),
(8, 'Argentina', 1, '2022-12-13 20:42:14', NULL, NULL),
(9, 'Armenia', 1, '2022-12-13 20:42:19', NULL, NULL),
(10, 'Australia', 1, '2022-12-13 20:42:23', NULL, NULL),
(11, 'Austria', 1, '2022-12-13 20:42:28', NULL, NULL),
(12, 'Azerbaijan', 1, '2022-12-13 20:42:33', NULL, NULL),
(13, 'Bahamas', 1, '2022-12-13 20:42:38', NULL, NULL),
(14, 'Bahrain', 1, '2022-12-13 20:42:43', NULL, NULL),
(15, 'Bangladesh', 1, '2022-12-13 20:42:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `current_vacancies`
--

CREATE TABLE `current_vacancies` (
  `current_vacancies_id` int(11) NOT NULL,
  `title` varchar(155) NOT NULL,
  `description` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `current_vacancies`
--

INSERT INTO `current_vacancies` (`current_vacancies_id`, `title`, `description`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Business Development Manager', '<p>DA-SEIN is seeking an ambitious and experienced Business Development Manager for our team in Dhanmondi,Dhaka.<br />\r\n<br />\r\nThe position will be an integral part of a dedicated team tasked with securing new and exciting opportunities for our growing practice. We are therefore looking for a person with a keen interest in the business side of design and architecture, who thrives working with a broad range of tasks and appreciates a lively, social, &amp; creative work environment.<br />\r\n<br />\r\nThe applications will be reviewed on a continual basis.</p>\r\n', 1, '2023-02-16 10:14:56', 1, NULL),
(2, 'Constructing Architect, 5+ years experience', '<p>Building designers with 5+ years of experience for a dynamic and international team DA-SEIN is looking for constructors with a minimum of 5 years of experience in project planning to join our team of architects, planners, landscape architects and constructors. The most important tasks are sketching and project planning of new projects in the order of 500-50,000 m2 with a focus on high architectural and urban quality. We are looking for candidates who speak and write fluent Bengali and English and have in-depth knowledge of Revit and BIM and Sketchup. We can offer both project employment and permanent employment (depending on the applicant&#39;s profile). We process applications on an ongoing basis, but the application deadline is 30 September 2022.</p>\r\n', 1, '2023-02-16 10:19:33', 1, NULL),
(3, 'Unsolicited Application', '', 1, '2023-02-16 10:19:52', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `education_id` int(11) NOT NULL,
  `education_name` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`education_id`, `education_name`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Master level ', 1, '2022-12-15 10:24:14', 1, NULL),
(2, 'Bachelor level', 1, '2022-12-15 10:25:14', NULL, NULL),
(3, 'Diploma level', 1, '2022-12-15 10:25:29', NULL, NULL),
(4, 'Gap Year', 1, '2022-12-15 10:25:35', NULL, NULL),
(5, 'Other', 1, '2022-12-15 10:25:45', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL,
  `event_name` text NOT NULL,
  `short_details` text NOT NULL,
  `location` varchar(155) NOT NULL,
  `event_date` date NOT NULL,
  `url` varchar(155) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `event_name`, `short_details`, `location`, `event_date`, `url`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'aaa', 'QQQQ', 'Bashundhara, Dhaka', '2022-12-08', 'http://test.dns/da_sein/public/', '1', 1, '2022-11-28 11:33:25', 1, '2022-11-28 11:33:25'),
(2, 'Building Green', 'qqqqq', 'Dhanmondi, dhaka', '2022-12-10', 'http://test.dns/da_sein/public/', '1', 1, '2022-11-28 11:46:15', 1, '2022-11-28 11:46:15');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `faq_id` int(11) NOT NULL,
  `title` varchar(155) NOT NULL,
  `description` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`faq_id`, `title`, `description`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'What is the working language?', '<p>Our working languages are Bangla and English.</p>\r\n\r\n<p>Everyone in the office is fluent in Bengali and at least in one other language.</p>\r\n', 1, '2022-12-15 10:53:14', 1, NULL),
(3, 'Do you encourage remote working or work-from-home?', '<p>Yes and no.<br />\r\n<br />\r\nOur entire team works from our office in Dhanmondi, Dhaka.<br />\r\n<br />\r\nHowever, everyone has the flexibility to work from home as needed. Most people prefer a full-time physical presence in the office or at least a couple of times per week.</p>\r\n', 1, '2022-12-20 11:34:09', 1, NULL),
(4, 'What software do you use?', '<p>We are a Windows-based office environment and work with a long list of software depending on your job description.<br />\r\n<br />\r\nEveryone in the office use</p>\r\n\r\n<ul>\r\n	<li>\r\n	<p>Microsoft Office</p>\r\n	</li>\r\n	<li>\r\n	<p>Adobe Creative Suite</p>\r\n	</li>\r\n	<li>\r\n	<p>Autodesk AutoCAD or LT</p>\r\n	</li>\r\n	<li>\r\n	<p>Rhino</p>\r\n	</li>\r\n	<li>\r\n	<p>Sketch-Up</p>\r\n	</li>\r\n</ul>\r\n\r\n<p><br />\r\nOur construction teams also work in</p>\r\n\r\n<ul>\r\n	<li>\r\n	<p>Revit</p>\r\n	</li>\r\n</ul>\r\n\r\n<ul>\r\n	<li>\r\n	<p>BIM360</p>\r\n	</li>\r\n</ul>\r\n\r\n<p>Our visualization team uses</p>\r\n\r\n<ul>\r\n	<li>\r\n	<p>3D Studio Max</p>\r\n	</li>\r\n	<li>\r\n	<p>VRay</p>\r\n	</li>\r\n	<li>\r\n	<p>Enscape</p>\r\n	</li>\r\n</ul>\r\n', 1, '2022-12-20 11:34:45', 1, NULL),
(5, 'What working-hours do you keep?', '<p>The week norm is 37 hours per week, depending on your contract.<br />\r\n<br />\r\nOur office is open weekdays from 08.00 (8 AM) to 18.00 (6 PM).<br />\r\n<br />\r\nMost people are present in the office from 9.00 (9 AM) - 17.00 (5 PM).<br />\r\n<br />\r\nThe remaining hours are placed based on each employee&rsquo;s individual schedule.<br />\r\n<br />\r\nAround deadlines, longer workdays must be expected. But naturally, compensatory time-off is given immediately following a deadline.</p>\r\n', 1, '2022-12-20 11:35:08', 1, NULL),
(6, 'What about vacation and holidays?', '<p>Everyone has a minimum of 5 weeks of paid vacation per year.<br />\r\n<br />\r\nYou earn your paid vacation from the day you start working.<br />\r\n<br />\r\nWe observe all national Bangladeshi holidays.</p>\r\n', 1, '2022-12-20 11:35:26', 1, NULL),
(7, 'How much do you pay in salary?', '<p>Salaries are negotiated on an individual level, based on seniority, talent and responsibilites.<br />\r\n<br />\r\nWe follow <a href=\"#\">the Collective Agreement</a> between <a href=\"#\">The Union of Architects and Designers (FAOD)</a> and Institute of Architects Bangladesh.</p>\r\n', 1, '2022-12-20 11:36:20', 1, NULL),
(8, 'How is the day-to-day management?', '<p>We have a management group consisting of our Founding Partners, our COO and CSO.<br />\r\n<br />\r\nThey work with project managers to help set the best teams and staff projects.<br />\r\n<br />\r\nAdministrative staff assists project team and management, in everything from contracting, finance, HR, operations, communication and business development.</p>\r\n', 1, '2022-12-20 11:36:42', NULL, NULL),
(9, 'How large are the project teams?', '<p>Each team consists of a Project Manager and a group of architects, landscape architects, constructing architects and junior architects.<br />\r\n<br />\r\nTypically, team sizes range from 1-3 architects and 1-2 juniors for concept design and competitions.<br />\r\n<br />\r\nDesign Development and construction teams are usually larger - 10-15 people.</p>\r\n', 1, '2022-12-20 11:42:45', 1, NULL),
(10, 'What are the requirements to do an internship?', '<p>We accept 6 - 8 interns during the spring and the fall semesters, which run from August through January and February through June.<br />\r\n<br />\r\nWe do not accept interns for periods shorter than 5 months.<br />\r\n<br />\r\nWe do not offer summer internships.<br />\r\n<br />\r\nAll applicants are expected to have a good level of spoken and written English and be proficient in Adobe, Rhino, and AutoCAD.<br />\r\n<br />\r\nApplications including a portfolio and a resume in .pdf format (no larger than 10 Mb) can be submitted to:<br />\r\n<br />\r\nhr@da-sein.com subject line: &#39;Internship&#39;<br />\r\n<br />\r\nEnrollment at an accredited University is required to be eligible for an internship. Graduates who hold a Master&rsquo;s degree from a Bangladeshi University or who are other than Bangladeshi citizens are not eligible to apply for internships.</p>\r\n', 1, '2022-12-20 11:43:15', 1, NULL),
(11, 'How do you select your interns?', '<p>Internship applications are reviewed bi-weekly and selected based on application and portfolio.<br />\r\n<br />\r\nWe look for aesthetic design skills, communication skills, conceptual ideas, technical skills, graphic skills, experience, etc.<br />\r\n<br />\r\nWe do not expect junior staff to master everything!<br />\r\n<br />\r\nIf you excel in something, play that to your advantage.</p>\r\n', 1, '2022-12-20 11:44:30', NULL, NULL),
(12, 'How is the social life of the office?', '<p>We eat lunch together every day at noon. Shared lunch is optional and part of the salary package. There are lunch options for both carnivores, vegetarians, vegans and the various allergens.<br />\r\n<br />\r\nWe have Friday coffee or parties once or twice a month. And, of course, annual summer parties and Eid parties (when health considerations allow for it).<br />\r\n<br />\r\nWe also have internal movie nights, lectures, etc.<br />\r\n<br />\r\nEvery two weeks we have an office-wide breakfast following an office briefing hosted by our CEO..</p>\r\n', 1, '2022-12-20 11:44:50', 1, NULL),
(13, 'Do you take study trips?', '<p>Every two years we visit the Contemporary &nbsp;Architecture Of Bangladesh.<br />\r\n<br />\r\nWe also do longer and shorter study trips to study architecture, culture and everything related to the built environment.<br />\r\n<br />\r\nThese trips are organized voluntarily by employees for employees.</p>\r\n', 1, '2022-12-20 11:45:09', 1, NULL),
(14, 'What is EUD?', '<p>EUD is a English abbreviation of &lsquo;Employee development and continuing education&acute;.<br />\r\n<br />\r\nFor each employee covered by the collective agreement, the company allocates an annual amount for continuing education.</p>\r\n\r\n<p>The funds are used to cover expenses incurred in respect of continuing education for study trips, courses, transport, etc.<br />\r\n<br />\r\nThe content of continuing education activities must be relevant to the company&rsquo;s current and potential fields of work and/or be considered an upgrade of the employee&rsquo;s professional qualifications.</p>\r\n', 1, '2022-12-20 11:45:27', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `global_settings`
--

CREATE TABLE `global_settings` (
  `id` int(11) NOT NULL,
  `title` varchar(155) NOT NULL,
  `value` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `global_settings`
--

INSERT INTO `global_settings` (`id`, `title`, `value`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'people_banner', 'people_slide_1675794215_e7a0c323132b014427ed.jpg', 1, '2023-02-08 00:23:36', NULL, '2022-11-14 16:35:20', NULL, NULL),
(2, 'publication_banner', 'publication_slide_1675798216_a58f08accccdec878faf.png', 1, '2023-02-08 01:30:16', NULL, '2022-11-14 16:35:20', NULL, NULL),
(3, 'client_banner', 'people_slide_1675798774_458c0363b54ff22dbbac.png', 1, '2023-02-08 01:39:35', NULL, '2022-11-14 16:35:20', NULL, NULL),
(4, 'event_banner', 'event_slide_1675799710_8078ba492098ffe3592c.png', 1, '2023-02-08 01:55:10', NULL, '2022-11-28 11:05:43', NULL, NULL),
(5, 'awards_banner', 'people_slide_1675799167_92355ad4129305d8246f.png', 1, '2023-02-08 01:46:08', NULL, '2022-11-28 12:07:01', NULL, NULL),
(6, 'image_unlock_code', '154301', 1, '2022-12-04 12:03:27', NULL, '2022-12-04 12:03:27', NULL, NULL),
(7, 'profile_banner', 'profile_slide_1690812056_efe53399bff5006b3864.jpg', 1, '2023-07-31 20:00:57', NULL, '2022-12-21 10:41:52', NULL, NULL),
(8, 'contact_banner', 'contact_slide_1675793658_07ea9dc934aed13f7b79.jpg', 1, '2023-02-08 00:14:19', NULL, '2022-12-21 10:52:25', NULL, NULL),
(9, 'employment_banner', 'employment_slide_1675794027_9b0b0c208b18301270dc.jpg', 1, '2023-02-08 00:20:27', NULL, '2022-12-21 11:03:38', NULL, NULL),
(10, 'podcasts_banner', 'podcasts_slide_1676794914_440f9a45876ffd04210c.png', 1, '2023-02-19 14:21:55', NULL, '2022-12-21 11:53:31', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `how_you_hear`
--

CREATE TABLE `how_you_hear` (
  `how_you_hear_id` int(11) NOT NULL,
  `how_you_hear_name` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `how_you_hear`
--

INSERT INTO `how_you_hear` (`how_you_hear_id`, `how_you_hear_name`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'website', 1, '2022-12-15 11:21:14', NULL, NULL),
(2, 'employee referral', 1, '2022-12-15 11:21:51', NULL, NULL),
(3, 'LinkedIn', 1, '2022-12-15 11:22:06', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `internship_application`
--

CREATE TABLE `internship_application` (
  `intern_id` int(11) NOT NULL,
  `intern_sem_id` int(11) NOT NULL,
  `email` varchar(155) NOT NULL,
  `last_name` varchar(155) NOT NULL,
  `first_name` varchar(155) NOT NULL,
  `phone` int(11) NOT NULL,
  `address` text NOT NULL,
  `zip_code` int(11) NOT NULL,
  `city` varchar(155) NOT NULL,
  `country_id` int(11) NOT NULL,
  `citizenship_ids` text NOT NULL,
  `language_ids` text NOT NULL,
  `software_ids` text NOT NULL,
  `university` text NOT NULL,
  `education_id` int(11) NOT NULL,
  `graduation_date` date DEFAULT NULL,
  `cv` varchar(155) NOT NULL,
  `portfolio` varchar(155) NOT NULL,
  `additional_documents` varchar(155) DEFAULT NULL,
  `linkedin` text DEFAULT NULL,
  `how_you_hear_id` int(11) NOT NULL,
  `additional_notes` text DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `internship_application`
--

INSERT INTO `internship_application` (`intern_id`, `intern_sem_id`, `email`, `last_name`, `first_name`, `phone`, `address`, `zip_code`, `city`, `country_id`, `citizenship_ids`, `language_ids`, `software_ids`, `university`, `education_id`, `graduation_date`, `cv`, `portfolio`, `additional_documents`, `linkedin`, `how_you_hear_id`, `additional_notes`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 1, 'admin@gmail.com', 'gfdg', 'dfgfd', 1923121212, 'sdfsfs', 12122, 'sdfs', 15, '[\"1\",\"2\"]', '[\"2\",\"1\"]', '[\"2\",\"3\"]', 'Bangla', 1, '2022-12-19', '1671454083_d4bb80d5f0a4a6210c95.pdf', '1671454083_cda5a5ed360f7b678204.pdf', '1671454083_645cfe6fd8071faf3cb0.pdf', 'https://www.effekt.dk/internship-application', 1, ' sdfdsfsd', 1, '2022-12-19 18:48:03', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `intern_sem`
--

CREATE TABLE `intern_sem` (
  `intern_sem_id` int(11) NOT NULL,
  `intern_sem_name` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intern_sem`
--

INSERT INTO `intern_sem` (`intern_sem_id`, `intern_sem_name`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Internship Fall \'23', 1, '2022-12-17 19:10:16', 1, NULL),
(2, 'Internship Spring \'24', 1, '2022-12-17 19:10:39', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `job_application`
--

CREATE TABLE `job_application` (
  `job_application_id` int(11) NOT NULL,
  `applied_position_id` int(11) DEFAULT NULL,
  `email` varchar(155) NOT NULL,
  `last_name` varchar(155) NOT NULL,
  `first_name` varchar(155) NOT NULL,
  `phone` int(11) NOT NULL,
  `address` text NOT NULL,
  `zip_code` int(11) NOT NULL,
  `city` varchar(155) NOT NULL,
  `country_id` int(11) NOT NULL,
  `experience_country_id` text DEFAULT NULL,
  `citizenship_ids` text NOT NULL,
  `language_ids` text NOT NULL,
  `software_ids` text NOT NULL,
  `university` text NOT NULL,
  `years_of_experience` int(11) DEFAULT NULL,
  `education_id` int(11) NOT NULL,
  `graduation_date` date DEFAULT NULL,
  `degree_title` varchar(255) DEFAULT NULL,
  `cv` varchar(155) NOT NULL,
  `portfolio` varchar(155) NOT NULL,
  `additional_documents` varchar(155) DEFAULT NULL,
  `linkedin` text DEFAULT NULL,
  `how_you_hear_id` int(11) NOT NULL,
  `salary_expectations` varchar(255) DEFAULT NULL,
  `additional_notes` text DEFAULT NULL,
  `available_start_date` date DEFAULT NULL,
  `review_process` int(11) DEFAULT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_application`
--

INSERT INTO `job_application` (`job_application_id`, `applied_position_id`, `email`, `last_name`, `first_name`, `phone`, `address`, `zip_code`, `city`, `country_id`, `experience_country_id`, `citizenship_ids`, `language_ids`, `software_ids`, `university`, `years_of_experience`, `education_id`, `graduation_date`, `degree_title`, `cv`, `portfolio`, `additional_documents`, `linkedin`, `how_you_hear_id`, `salary_expectations`, `additional_notes`, `available_start_date`, `review_process`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 1, 'admin@gmail.com', 'gdfgd', 'dffgdf', 1923121212, 'fgjfj', 4567, 'hfghf', 15, '[\"2\",\"7\",\"5\"]', '[\"1\",\"2\"]', '[\"2\",\"1\"]', '[\"2\",\"3\"]', 'fghfgh', 1, 1, '2016-06-20', 'dgfdg', '1671533560_ecd7cbc48fc803359c62.pdf', '1671533560_0d63abd843de538cf652.pdf', '1671533560_8736508d74af31f9fe4a.pdf', 'https://www.effekt.dk/apply-now', 1, '500', ' erwrewr', '2023-01-01', 1, 1, '2022-12-20 16:52:40', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE `language` (
  `language_id` int(11) NOT NULL,
  `language_name` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`language_id`, `language_name`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'English', 1, '2022-12-17 19:22:57', NULL, NULL),
(2, 'Bangla', 1, '2022-12-17 19:23:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `news_id` int(11) NOT NULL,
  `news_title` varchar(155) NOT NULL,
  `slug` text NOT NULL,
  `short_des` varchar(155) NOT NULL,
  `news_description` text NOT NULL,
  `meta_title` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  `news_type` varchar(155) NOT NULL,
  `image` varchar(255) NOT NULL,
  `years` year(4) NOT NULL,
  `publish_date` date DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `news_title`, `slug`, `short_des`, `news_description`, `meta_title`, `meta_keyword`, `meta_description`, `news_type`, `image`, `years`, `publish_date`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`) VALUES
(3, 'Submission of Crest Design for IAB', 'submission-of-crest-design-for-iab', 'Crest Design for IAB', 'The IAB Awards are the most prestigious professional architectural awards in the country. which is given every two years. Originally established as the IAB Design Awards in 1996, to recognize, honor, and promote outstanding examples of contemporary architecture in Bangladesh, and to encourage excellence in architectural practice. ', 'Crest Design for IAB', 'Crest Design for IAB', 'Crest Design for IAB', 'Crest Design for IAB', 'news_1690861275_0b4ca03b3d78157ac668.jpg', 2017, '2010-01-17', '1', '2022-11-14 11:15:08', 1, '2023-08-01 09:41:15', 1),
(19, 'Office Assistant', 'office-assistant', 'Office Assistant', 'We are looking for a service-minded and energetic office assistant for our busy office. As an Office Assistant, you will be an important part of the office and be with us to contribute to a well-functioning everyday life.\r\n\r\n\r\nThe work tasks will be a combination of administrative and practical tasks, and there are good opportunities for competence development in a creative and international working environment. The position is wished to be filled as soon as possible and no later than 1 February 2023.\r\n\r\n\r\nRead more about the position here.\r\n\r\n\r\nThank you for your interest. The position has now been filled.\r\n', 'Job postings', 'Job postings', 'Office Assistant', 'Office Assistant', 'news_1690861287_7d2b8293d9ed266e9114.jpg', 2023, '2023-04-01', '1', '2023-02-11 21:34:01', 1, '2023-08-01 09:41:27', 1),
(26, 'Visiting The Carpenter Center for the Visual Arts', 'visiting-the-carpenter-center-for-the-visual-arts', '', 'The Carpenter Center for the Visual Arts, Harvard University ,24 Quincy StreetCambridge, Boston, MA 02138, completed in 1963, is the only building on the North American continent designed by the famous Swiss-born architect Le Corbusier. Despite the controversy over the wisdom of placing a building of such modern design in a traditional location, Le Corbusier felt that a building devoted to the visual arts must be an experience of freedom and unbound creativity. A traditional building for the visual arts would have been a contradiction. The Carpenter Center represents Corbusier’s attempt to create a “synthesis of the arts,” the union of architecture with painting, sculpture, through his innovative design. The building was completed in 1963, made possible by a gift from Alfred St. Vrain Carpenter, and the intent to house the artistic entities of Harvard College under one roof came to fruition in 1968 as the Department of Visual and Environmental Studies, renamed in 2019 as the Department of Art, Film, and Visual Studies.', '', '', '', 'Harvard University 24 Quincy Street Cambridge, MA 02138', 'news_1690861316_4ca4e869c0c311666b46.jpg', 2023, '2023-04-14', '1', '2023-04-15 06:31:13', 1, '2023-08-01 09:41:57', 1),
(27, 'Visiting The Boston Government Service Center', 'visiting-the-boston-government-service-center', 'The Boston Government Service Center (BGSC) is a state government complex in the West End of Boston, Massachusetts. The center was designed in the Brutalis', 'The Boston Government Service Center (BGSC) is a state government complex in the West End of Boston, Massachusetts. The center was designed in the Brutalist style, led by architect Paul Rudolph. It is one of the major components of the Government Center complex in Downtown Boston. The complex is made up of two connected Brutalist buildings: the Charles F. Hurley Building and the Erich Lindemann Building, as well as a courtyard; sometimes included is the newer, 1998-built, Edward W. Brooke Courthouse.\r\nThe Hurley and Lindemann buildings are designated Category Two buildings in Boston, holding major significance for the city. The site is eligible for the state and national registers of historic places, and as a Boston Landmark. Its association with Rudolph and its extreme architectural style make it a possible National Historic Landmark.\r\n', '', '', '', 'Visiting The Boston Government Service Center', 'news_1690861327_8753aa18e2c5e27ca921.jpg', 2023, '2023-04-23', '1', '2023-04-23 12:02:39', 1, '2023-08-01 09:42:07', 1),
(35, 'Visiting  Bill & Melinda Gates Hall / Morphosis Architects', 'visiting-bill-melinda-gates-hall-morphosis-architects', '', 'Bill & Melinda Gates Hall was designed by Morphosis Architects. Morphosis is an interdisciplinary architectural practice involved in rigorous design and research that yields innovative, iconic buildings and urban environments. With founder Pritzker prize-winning architect Thom Mayne serving as design director, the firm is committed to the practice of architecture as a collaborative enterprise. In addition to Bill & Melinda Gates Hall, Morphosis was chosen to design the first academic building on Cornell Tech\'s New York City campus. Perhaps best known in New York for its sculptural and futuristic Cooper Union Arts and Sciences building, Morphosis\' Cornell buildings are sure to become upstate-downstate high-tech icons.', '', '', '', 'Visiting Bill & Melinda Gates Hall ', 'news_1690861339_6aa0396e67676dd9a2b7.jpg', 2016, '2023-07-08', '1', '2023-06-09 02:23:32', 1, '2023-08-01 10:44:06', 1),
(41, 'rtreter', 'rtreter', 'retret', 'retert', 'rtretre', 'rtertre', 'tertert', 'retert', '', 2016, '2023-07-31', '1', '2023-08-01 10:04:34', 1, '2023-08-01 10:44:26', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news_gallary`
--

CREATE TABLE `news_gallary` (
  `news_gallary_id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `image` varchar(155) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news_gallary`
--

INSERT INTO `news_gallary` (`news_gallary_id`, `news_id`, `image`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`) VALUES
(4, 41, 'news_1690864658_94f35f3573b624af7e65.jpg', '2023-08-01 10:37:38', NULL, NULL, NULL),
(5, 41, 'news_1690864658_3d2cb057c26b96dc515e.jpg', '2023-08-01 10:37:39', NULL, NULL, NULL),
(6, 41, 'news_1690864715_c14acf8011e24ed31122.jpg', '2023-08-01 10:38:36', NULL, NULL, NULL),
(7, 3, 'news_1690864766_f79343f44582bfd1bbd8.jpg', '2023-08-01 10:39:26', NULL, NULL, NULL),
(8, 3, 'news_1690864766_49c8519e3042c54a4c07.jpg', '2023-08-01 10:39:27', NULL, NULL, NULL),
(9, 3, 'news_1690864767_013b58bf69086b7c33fd.jpg', '2023-08-01 10:39:28', NULL, NULL, NULL),
(10, 19, 'news_1690864783_5ccb38f85d2b177c11e9.jpg', '2023-08-01 10:39:43', NULL, NULL, NULL),
(11, 19, 'news_1690864783_2629ee2dfad69e27abd8.jpg', '2023-08-01 10:39:44', NULL, NULL, NULL),
(12, 19, 'news_1690864784_2ecbea6acf616c96fa0d.jpg', '2023-08-01 10:39:44', NULL, NULL, NULL),
(13, 26, 'news_1690864798_2d37aa774e8921fcd316.jpg', '2023-08-01 10:39:58', NULL, NULL, NULL),
(14, 26, 'news_1690864798_d8a6d923c8aa2fd95e9e.jpg', '2023-08-01 10:39:59', NULL, NULL, NULL),
(15, 26, 'news_1690864799_9e66d70d914d3154e569.jpg', '2023-08-01 10:40:00', NULL, NULL, NULL),
(16, 27, 'news_1690864816_11032c55981d22f28214.jpg', '2023-08-01 10:40:17', NULL, NULL, NULL),
(17, 27, 'news_1690864817_4edbd88f951f63f1f5b7.jpg', '2023-08-01 10:40:17', NULL, NULL, NULL),
(18, 27, 'news_1690864817_8915b9af53947e86bd41.jpg', '2023-08-01 10:40:18', NULL, NULL, NULL),
(19, 35, 'news_1690864832_f4b223e6b1d504c42ffc.jpg', '2023-08-01 10:40:33', NULL, NULL, NULL),
(20, 35, 'news_1690864833_eda3ad0958feaaeae7ba.jpg', '2023-08-01 10:40:33', NULL, NULL, NULL),
(21, 35, 'news_1690864833_af37e3eaa40ae835ba2d.jpg', '2023-08-01 10:40:34', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE `people` (
  `people_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `post` varchar(155) NOT NULL,
  `email` varchar(155) NOT NULL,
  `photo` varchar(155) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdBy` int(11) DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`people_id`, `name`, `post`, `email`, `photo`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Rashidur Rahman', 'Rashidur Rahman', 'rashidur@da-sein.com', 'people_1677341748_bbd504c469a7f707ebb1.jpg', '1', 1, '2022-11-27 17:13:42', 1, '2022-11-27 17:13:42'),
(2, 'Mehedi Hasan', 'Mehedi Hasan', 'mehedi@da-sein.com', 'people_1677848053_6f60ad8d120cf9a86ce7.jpg', '1', 1, '2022-11-27 17:14:19', 1, '2022-11-27 17:14:19'),
(3, 'Pratiik Emon', 'Pratiik Emon', 'rashidur@da-sein.com', 'people_1675796241_ac7aa43bb84f272046a4.jpg', '1', 1, '2022-11-27 17:14:42', 1, '2022-11-27 17:14:42'),
(4, 'Roman Ur Rahman', 'Roman Ur Rahman', 'rashidur@da-sein.com', 'people_1675796467_dbb4dffc198574518ea7.jpg', '1', 1, '2022-11-27 17:15:14', 1, '2022-11-27 17:15:14'),
(5, 'Khalid Zarir', 'Khalid Zarir', 'rashidur@da-sein.com', 'people_1675796558_c7cf5982b4b28e12a80a.jpg', '1', 1, '2022-11-27 17:15:42', 1, '2022-11-27 17:15:42'),
(6, 'Mehedi Shawon', 'Mehedi Shawon', 'rashidur@da-sein.com', 'people_1675796615_4b26766d877f14610b43.jpg', '1', 1, '2022-11-27 17:16:08', 1, '2022-11-27 17:16:08');

-- --------------------------------------------------------

--
-- Table structure for table `podcasts`
--

CREATE TABLE `podcasts` (
  `podcasts_id` int(11) NOT NULL,
  `podcasts_name` varchar(155) NOT NULL,
  `youtube_url` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `podcasts`
--

INSERT INTO `podcasts` (`podcasts_id`, `podcasts_name`, `youtube_url`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'uu', '11', 1, '2022-12-21 12:02:04', 1, NULL),
(2, 'gggg', 'ggg', 1, '2022-12-21 12:03:29', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `publication`
--

CREATE TABLE `publication` (
  `publication_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `author` varchar(155) NOT NULL,
  `publisher` varchar(155) NOT NULL,
  `published` varchar(155) NOT NULL,
  `language` varchar(155) NOT NULL,
  `format` varchar(155) NOT NULL,
  `binding` varchar(155) NOT NULL,
  `page_count` int(11) NOT NULL,
  `image` text NOT NULL,
  `status` enum('0','1') DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `publication`
--

INSERT INTO `publication` (`publication_id`, `name`, `title`, `author`, `publisher`, `published`, `language`, `format`, `binding`, `page_count`, `image`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Le corbusier\'s Hand', 'Translation of Le corbusier\'s Hand', 'André Wogenscky Translated by RASHIDUR RAHMAN', 'Monduar', 'October 2024', 'Bangla/ English', '18 x 25 cm', 'Hardcover', 120, 'publication_1675797825_7d825f03469bcf97a20b.png', '1', 1, '2022-11-27 20:23:09', 1, '2022-11-27 20:23:09'),
(2, 'The Modular', 'The Modular', 'Le Corbusier, Translated by RASHIDUR RAHMAN', 'Monduar', 'March 2020', 'English', '15 x 24 cm', 'Hardcover', 104, 'publication_1675798458_a56240840cfe30c5ac40.png', '1', 1, '2022-11-27 20:25:24', 1, '2022-11-27 20:25:24');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `sl_id` int(11) NOT NULL,
  `name` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(155) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('0','1') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`sl_id`, `name`, `image`, `status`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`) VALUES
(1, 'Mr Shahedul\'s Residence', 'news_1690811166_034b187a508e04abb793.jpg', '1', '2022-11-15 16:53:01', NULL, '2023-07-31 19:46:06', NULL),
(2, 'Mr Shahedul\'s Residence', 'news_1690811173_d17820daca83e49e1822.jpg', '1', '2022-11-15 16:53:06', NULL, '2023-07-31 19:46:13', NULL),
(3, 'B.E.R.C', 'news_1690811186_d719c8a696a9b9c8edb8.jpg', '1', '2022-11-15 16:53:11', NULL, '2023-07-31 19:46:26', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `software_knowledge`
--

CREATE TABLE `software_knowledge` (
  `software_id` int(11) NOT NULL,
  `software_name` varchar(155) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `software_knowledge`
--

INSERT INTO `software_knowledge` (`software_id`, `software_name`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(2, 'Adobe Acrobat', 1, '2022-12-18 10:44:51', NULL, NULL),
(3, '3D max', 1, '2022-12-18 10:45:33', 1, NULL),
(4, 'Autocad', 1, '2023-02-12 20:54:18', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `subscribe_id` int(11) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscribe`
--

INSERT INTO `subscribe` (`subscribe_id`, `email`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'rashidur.dasein@gmai.com', '1', 1, '2023-03-05 19:51:36', NULL, NULL, NULL, NULL),
(2, 'ROnF_generic_a88b7dcd_da-sein.com@data-backup-store.com', '1', 1, '2023-03-15 08:16:42', NULL, NULL, NULL, NULL),
(3, 'AlikiBerland181@aol.com', '1', 1, '2023-03-25 06:03:28', NULL, NULL, NULL, NULL),
(4, 'AlikiBerland181@aol.com', '1', 1, '2023-03-25 06:03:29', NULL, NULL, NULL, NULL),
(5, 'qakgagiluw@outlook.com', '1', 1, '2023-04-04 18:59:55', NULL, NULL, NULL, NULL),
(6, 'qakgagiluw@outlook.com', '1', 1, '2023-04-04 18:59:57', NULL, NULL, NULL, NULL),
(7, 'm0Rk_generic_a88b7dcd_da-sein.com@data-backup-store.com', '1', 1, '2023-04-05 12:57:46', NULL, NULL, NULL, NULL),
(8, 'lkcn_generic_a88b7dcd_da-sein.com@data-backup-store.com', '1', 1, '2023-04-06 13:00:41', NULL, NULL, NULL, NULL),
(9, 'DianKeeling552@yahoo.com', '1', 1, '2023-04-29 17:01:50', NULL, NULL, NULL, NULL),
(10, 'DianKeeling552@yahoo.com', '1', 1, '2023-04-29 17:01:51', NULL, NULL, NULL, NULL),
(11, 'mehedishawon96@gmail.com', '1', 1, '2023-05-04 16:47:25', NULL, NULL, NULL, NULL),
(12, '0lYt_generic_a88b7dcd_da-sein.com@data-backup-store.com', '1', 1, '2023-05-18 04:24:53', NULL, NULL, NULL, NULL),
(13, 'SK@SAYEMKHAN.WORK', '1', 1, '2023-05-25 13:07:57', NULL, NULL, NULL, NULL),
(14, 'dwCg_generic_a88b7dcd_da-sein.com@data-backup-store.com', '1', 1, '2023-05-30 18:28:18', NULL, NULL, NULL, NULL),
(15, 'LouW_generic_a88b7dcd_da-sein.com@data-backup-store.com', '1', 1, '2023-06-15 19:00:09', NULL, NULL, NULL, NULL),
(16, 'vx3y_generic_a88b7dcd_da-sein.com@data-backup-store.com', '1', 1, '2023-06-20 20:29:11', NULL, NULL, NULL, NULL),
(17, 'ln-studio@outlook.com', '1', 1, '2023-07-02 09:13:21', NULL, NULL, NULL, NULL),
(18, 'eYvM_generic_a88b7dcd_da-sein.com@data-backup-store.com', '1', 1, '2023-07-22 01:44:00', NULL, NULL, NULL, NULL),
(19, 'vjEP_generic_a88b7dcd_da-sein.com@data-backup-store.com', '1', 1, '2023-07-29 12:58:41', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `works`
--

CREATE TABLE `works` (
  `work_id` int(11) NOT NULL,
  `project_name` text NOT NULL,
  `cat_id` int(11) NOT NULL,
  `slug` text DEFAULT NULL,
  `news_description` text NOT NULL,
  `meta_title` text DEFAULT NULL,
  `meta_keyword` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `typology` varchar(155) DEFAULT NULL,
  `location` varchar(155) DEFAULT NULL,
  `year` varchar(155) DEFAULT NULL,
  `img_unlock_code` int(11) DEFAULT NULL,
  `project_status` varchar(155) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `client` varchar(255) DEFAULT NULL,
  `copyright` varchar(255) DEFAULT NULL,
  `gfa_size` varchar(255) DEFAULT NULL,
  `design_team` text DEFAULT NULL,
  `collaborators` text DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) NOT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `works`
--

INSERT INTO `works` (`work_id`, `project_name`, `cat_id`, `slug`, `news_description`, `meta_title`, `meta_keyword`, `meta_description`, `typology`, `location`, `year`, `img_unlock_code`, `project_status`, `size`, `client`, `copyright`, `gfa_size`, `design_team`, `collaborators`, `status`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`) VALUES
(2, '“Landmark Monument” ', 5, '-landmark-monument-', 'The University of Dhaka has allocated development funds for the “construction of Landmark Monument: Celebrating 100 Years of the University of Dhaka and Golden Jubilee of Independence of Bangladesh” in mall area on the spot earlier selected to construct “Kendrio Shahid Minar” by Ex. VC Professor Dr. Muzaffar Ahmed Chaudhury in 1972. The Landmark Monument will represent the DU over its 100 years journey incorporating knowledge and our struggle for freedom.', 'Landmark Monument, Dhaka University', 'Landmark Monument, Dhaka University', 'Landmark Monument, Dhaka University', 'Landscape', 'Dhaka', '2019', 303863, 'Submitted', '333', '0', NULL, NULL, 'Da-sein team', 'None', '1', '2022-11-19 11:07:31', 1, '2023-03-14 09:49:51', 1),
(5, 'BERC Head Office', 1, 'berc-head-office', 'BERC Head Office', 'UJUJ', 'UJUJU', '9IKIKI', 'Research', '', '2021-2022', 110553, 'Competition Entry', '', 'BERC', 'DaseIN ARCHITECTS', '', '', 'Axis Design Studio', '1', '2022-11-19 11:03:12', 1, '2023-06-25 11:07:13', 1),
(9, 'Liberation War Museum', 3, 'liberation-war-museum', 'The Liberation War Museum ( Muktijuddho Jadughôr) is a museum at Agargaon in Dhaka,the capital of Bangladesh, which commemorates the Bangladesh Liberation War that led to the independence of Bangladesh from Pakistan.\r\nThe Liberation War Museum began under the initiative of an eight-person board of trustees as a means of preserving the memory of the 1971 Liberation War. The trustees sought donations from the general public to fund the museum and for the general public to come forward with artifacts to be displayed artifacts from the war, including personal belongings, weapons and human remains, as well as creating an archive of documents and personal histories related to the war. Over the years the museum collected more than 21,000 artifacts (as of 2016), with some as exhibits on display in the museum and many more stored in its archives. The museum describes itself as \"the outcome of a citizens\' effort\" due to the crowd-funded nature of the museum (which is independent of the Govt. of Bangladesh) and the collective contribution of the general public to the museum\'s collection.', '', '', '', 'civic', 'Plot : F11/A & F11/B Sher-E Bangla Nagar, Civic Centre, Agargaon, Dhaka', '2009', NULL, 'Competition Entry', '444', '0', 'Da-sein Architects 2009', '44444', 'Da-sein Architects', 'N/A', '1', '2023-02-12 12:30:20', 1, '2023-03-17 21:34:52', 1),
(14, 'Officer\'s Quarter in Tongi', 2, 'officer-s-quarter-in-tongi', 'Officer and Staff Quarter in Tongi', '', '', '', 'hospitality', 'Tongi, Gazipur', '2021-2022', NULL, 'Under construction', '', 'Ananda Group', 'DASEIN ARCHITECTS', '', '', 'dvd', '1', '2023-02-22 02:07:18', 1, '2023-06-25 11:01:19', 1);

-- --------------------------------------------------------

--
-- Table structure for table `work_gallary`
--

CREATE TABLE `work_gallary` (
  `work_gallary_id` int(11) NOT NULL,
  `work_id` int(11) NOT NULL,
  `image` varchar(155) NOT NULL,
  `protected` enum('0','1') NOT NULL DEFAULT '0',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `work_gallary`
--

INSERT INTO `work_gallary` (`work_gallary_id`, `work_id`, `image`, `protected`, `createdDtm`, `createdBy`, `updatedDtm`, `updatedBy`) VALUES
(42, 5, 'work_1690811949_c0b759723ac7ce7594d2.jpg', '0', '2023-02-22 01:40:49', NULL, NULL, NULL),
(44, 14, 'work_1690811810_7bf3d79523e2cefcad5f.jpg', '0', '2023-02-22 02:07:18', NULL, NULL, NULL),
(47, 9, 'work_1690811905_a93757e90997eecb46be.jpg', '0', '2023-02-22 10:51:31', NULL, NULL, NULL),
(125, 14, 'work_1690811818_c25fe5e1583f126004f6.jpg', '0', '2023-06-25 10:51:31', NULL, NULL, NULL),
(129, 14, 'work_1690811839_73deb5ee0de3cedf381b.jpg', '0', '2023-07-31 19:57:19', NULL, NULL, NULL),
(130, 14, 'work_1690811839_a54497582594f5b4af4b.jpg', '0', '2023-07-31 19:57:19', NULL, NULL, NULL),
(131, 14, 'work_1690811839_76e972e72f9b69e48aba.jpg', '0', '2023-07-31 19:57:20', NULL, NULL, NULL),
(132, 9, 'work_1690811927_a3b65d27a2ce9b51e717.jpg', '0', '2023-07-31 19:58:47', NULL, NULL, NULL),
(133, 9, 'work_1690811927_ff3bc10b4a85d36a1764.jpg', '0', '2023-07-31 19:58:48', NULL, NULL, NULL),
(134, 9, 'work_1690811928_f5bfde4a89755d203d97.jpg', '0', '2023-07-31 19:58:49', NULL, NULL, NULL),
(135, 5, 'work_1690811958_45ad75e9f1a2aaecda77.jpg', '0', '2023-07-31 19:59:19', NULL, NULL, NULL),
(136, 5, 'work_1690811959_76e4a56d2c697b3b17bf.jpg', '0', '2023-07-31 19:59:20', NULL, NULL, NULL),
(137, 2, 'work_1690812023_bac4697757576dc59fec.jpg', '0', '2023-07-31 20:00:24', NULL, NULL, NULL),
(138, 2, 'work_1690812024_537d2c509dd95ce9fa42.jpg', '0', '2023-07-31 20:00:25', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `applied_position`
--
ALTER TABLE `applied_position`
  ADD PRIMARY KEY (`applied_position_id`);

--
-- Indexes for table `awards`
--
ALTER TABLE `awards`
  ADD PRIMARY KEY (`award_id`);

--
-- Indexes for table `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`block_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `citizenship`
--
ALTER TABLE `citizenship`
  ADD PRIMARY KEY (`citizenship_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `current_vacancies`
--
ALTER TABLE `current_vacancies`
  ADD PRIMARY KEY (`current_vacancies_id`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`education_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`faq_id`);

--
-- Indexes for table `global_settings`
--
ALTER TABLE `global_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `how_you_hear`
--
ALTER TABLE `how_you_hear`
  ADD PRIMARY KEY (`how_you_hear_id`);

--
-- Indexes for table `internship_application`
--
ALTER TABLE `internship_application`
  ADD PRIMARY KEY (`intern_id`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `education_id` (`education_id`),
  ADD KEY `how_you_hear_id` (`how_you_hear_id`),
  ADD KEY `intern_sem_id` (`intern_sem_id`);

--
-- Indexes for table `intern_sem`
--
ALTER TABLE `intern_sem`
  ADD PRIMARY KEY (`intern_sem_id`);

--
-- Indexes for table `job_application`
--
ALTER TABLE `job_application`
  ADD PRIMARY KEY (`job_application_id`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `education_id` (`education_id`),
  ADD KEY `how_you_hear_id` (`how_you_hear_id`),
  ADD KEY `applied_position_id` (`applied_position_id`);

--
-- Indexes for table `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`language_id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `news_gallary`
--
ALTER TABLE `news_gallary`
  ADD PRIMARY KEY (`news_gallary_id`),
  ADD KEY `work_id` (`news_id`);

--
-- Indexes for table `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`people_id`);

--
-- Indexes for table `podcasts`
--
ALTER TABLE `podcasts`
  ADD PRIMARY KEY (`podcasts_id`);

--
-- Indexes for table `publication`
--
ALTER TABLE `publication`
  ADD PRIMARY KEY (`publication_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`sl_id`);

--
-- Indexes for table `software_knowledge`
--
ALTER TABLE `software_knowledge`
  ADD PRIMARY KEY (`software_id`);

--
-- Indexes for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD PRIMARY KEY (`subscribe_id`);

--
-- Indexes for table `works`
--
ALTER TABLE `works`
  ADD PRIMARY KEY (`work_id`);

--
-- Indexes for table `work_gallary`
--
ALTER TABLE `work_gallary`
  ADD PRIMARY KEY (`work_gallary_id`),
  ADD KEY `work_id` (`work_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `applied_position`
--
ALTER TABLE `applied_position`
  MODIFY `applied_position_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `awards`
--
ALTER TABLE `awards`
  MODIFY `award_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `blocks`
--
ALTER TABLE `blocks`
  MODIFY `block_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `citizenship`
--
ALTER TABLE `citizenship`
  MODIFY `citizenship_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `current_vacancies`
--
ALTER TABLE `current_vacancies`
  MODIFY `current_vacancies_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `education_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `faq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `global_settings`
--
ALTER TABLE `global_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `how_you_hear`
--
ALTER TABLE `how_you_hear`
  MODIFY `how_you_hear_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `internship_application`
--
ALTER TABLE `internship_application`
  MODIFY `intern_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `intern_sem`
--
ALTER TABLE `intern_sem`
  MODIFY `intern_sem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `job_application`
--
ALTER TABLE `job_application`
  MODIFY `job_application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `language`
--
ALTER TABLE `language`
  MODIFY `language_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `news_gallary`
--
ALTER TABLE `news_gallary`
  MODIFY `news_gallary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `people`
--
ALTER TABLE `people`
  MODIFY `people_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `podcasts`
--
ALTER TABLE `podcasts`
  MODIFY `podcasts_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `publication`
--
ALTER TABLE `publication`
  MODIFY `publication_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `sl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `software_knowledge`
--
ALTER TABLE `software_knowledge`
  MODIFY `software_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subscribe`
--
ALTER TABLE `subscribe`
  MODIFY `subscribe_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `works`
--
ALTER TABLE `works`
  MODIFY `work_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `work_gallary`
--
ALTER TABLE `work_gallary`
  MODIFY `work_gallary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `work_gallary`
--
ALTER TABLE `work_gallary`
  ADD CONSTRAINT `work_gallary_ibfk_1` FOREIGN KEY (`work_id`) REFERENCES `works` (`work_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
